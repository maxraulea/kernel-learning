#include "type.h"
#define strlen mstrlen
#define putc vputc

#define KCODE	    0x08
#define KDATA	    0x10
/********* without the LDT, user segments are in GDT ****************
            0    1   2   3   4   5
          |null|KCS|KDS|TSS|UCS|UDS|
 where 4=> index=100|T=0|PL=11 = 0x23, 5=>101|T=0|PL=11 = 0x2B
********************************************************************/
#define USER_CODE   0x23
#define USER_DATA   0x2B

#define GDT_ADDR    0x80104000
#define GDT_ENTRIES 6
#define GDT_SIZE    (8*GDT_ENTRIES)

#define IDT_ADDR    0x80105000
#define IDT_SIZE       (256*8)

// kpgdir and pagtables are in 4MB
#define KPG_DIR     0x80106000
/*****************************************************************
 For some reason, VMware corrupts pgtables in 4MB. Before figuring
 out WHY, let pgtables be in 3MB. For QEMU, it does not matter!
*****************************************************************/
#ifdef VMWARE
#define KPG_TABLE        0x80300000
#endif
#ifdef QEMU
#define KPG_TABLE        0x80400000
#endif
// PROCs are in 5MB
#define PROC_BASE   0x80500000
#define PRES_BASE   0x805E0000

// I/O buffer 1KB data areas are in 7MB
#define BUFFER_BASE 0x80700000

#define GDT_TSS_INDEX       3
#define GDT_TSS_SEL      0x18

/*** UCS selector=0111=index=0, LDT=1, RPL=11; UDS=1111: index=1,LDT,RPL=11 */
#define UCS              0x23
#define UDS              0x2B
#define USS              0x2B
#define UFLAG          0x3202
#define SYS_CALL         0x80

#define VA(x) ((x) + 0x80000000)
#define PA(x) ((x) - 0x80000000)

#define printf printk
int printk(char *fmt,...);

extern int (*intEntry[ ])();
extern int (*intHandler[ ])();
extern void default_trap(void);

extern int int80h();
extern int hdinth(), kbinth(), tinth(), kcinth(), fdinth(), s0inth(), s1inth();
extern int printh(), cdinth();

extern u8 btime[8];  // centry, year, month, day, bhr, bmin, bsec, bpad;
extern u32 hr, min, sec;

char *strcpy(), *strcat();
struct buf *bread(), *getblk();

extern  int    color;
#define CYAN   0x0B
#define RED    0x0C
#define PURPLE 0x0D

extern void goUmode();

extern PROC  *proc;
extern PROC *running;
extern PROC *readyQueue;
extern PROC *freeList;
extern PROC *tfreeList;
extern PROC *sleepList;

extern u64  *gdt;
extern u32  *kpgdir;
extern u32  *pfreeList;

extern int  kernel_init();
extern void loader();


extern MINODE *root;
extern int   ntasks;
extern int   HD;

extern int   hd_rw();

extern struct semaphore loadsem;
extern struct semaphore kbData;

extern void  bcopy(), *memset(), bzero(), *memcpy();
extern char *strcpy(),*strncpy(), *strstr(), *strcat();
extern char *strcpy(), *strcat();

extern int vputc(char);
