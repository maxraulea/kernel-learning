/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/************************** timer.c ****************************************/
#include "../include.h"

/* timer parameters. */
#define LATCH_COUNT     0x00	/* cc00xxxx, c = channel, x = any */
#define SQUARE_WAVE     0x36	/* ccaammmb, a = access, m = mode, b = BCD */
#define TIMER_FREQ   1193182L	/* timer frequency */
#define TIMER_COUNT ((unsigned) (TIMER_FREQ/60)) /* initial value for counter*/

#define TIMER0       0x40
#define TIMER_MODE   0x43
#define CLOCK_IRQ       0

int row, col;
u32 tick, sec, min, hr, day;

typedef struct tn{
       struct tn *next;
       int    time;
       PROC   *who;
} TNODE;

TNODE tnode[NPROC], *tq, *ft;

u8 btime[8];  // centry, year, month, day, bhr, bmin, bsec, bpad;

int ptime(u8 t[8])
{
   printf("date=%c%c%c%c-%c%c-%c%c  ",
          (t[0]>>4)+'0', (t[0]&0x0F)+'0',
          (t[1]>>4)+'0', (t[1]&0x0F)+'0', 
          (t[2]>>4)+'0', (t[2]&0x0F)+'0',
          (t[3]>>4)+'0', (t[3]&0x0F)+'0'
         );
   printf("time=%c%c:%c%c:%c%c\n",
          (t[4]>>4)+'0', (t[4]&0x0F)+'0',
          (t[5]>>4)+'0', (t[5]&0x0F)+'0', 
          (t[6]>>4)+'0', (t[6]&0x0F)+'0'
         );
}

/*===========================================================================*
 *				timer_init				     *
 *===========================================================================*/
void timer_init()
{
  int i;
  tick = 0;

  /* get boot time from saved BIOS time */
  for (i=0; i<8; i++)
         btime[i] = *(u8 *)(0x80090000+i);

  // set day, hr min sec to BIOS real time
  /******** u8 btime[3,4,5,6] = |day|hr|mm|sec| *********/
   day = 10*(btime[3]>>4); day += btime[3]&0x0f;
   hr  = 10*(btime[4]>>4); hr  += btime[4]&0x0f;
   min = 10*(btime[5]>>4); min += btime[5]&0x0f;
   sec = 10*(btime[6]>>4); sec += btime[6]&0x0f;
   //printf("hr:min:sec = %d:%d:%d\n", hr, min,sec);
   ptime(btime);

  /* initialize interval timer queue */
  ft = &tnode[0]; 
  for (i=0; i<NPROC; i++)
    tnode[i].next = &tnode[i+1];
  tnode[NPROC-1].next=0;
  tq = 0;

  /* Initialize channel 0 of the 8253A timer to e.g. 60 Hz. */
  out_byte(TIMER_MODE, SQUARE_WAVE);	/* set timer to run continuously */
  out_byte(TIMER0, TIMER_COUNT);	/* load timer low byte */
  out_byte(TIMER0, TIMER_COUNT >> 8);	/* load timer high byte */

  out_byte(0x21,0x80);
}

/*===========================================================================*
 *				timer_handler				     *
 *===========================================================================*/
char *wall="00:00:ss";
/*          01234567 */
u16 w;

extern int color;

extern int motor_status, fd_motor_off;   // in floppy disk driver fd.c
extern int tout, fd_timeout;
extern struct semaphore fdsem;
extern int need_reset, fdreset, IFLAG;                 // FD need reset flag
extern PROC *readyQueue;
extern int org;
extern int sw_flag;

#define QUANTA 20
#define SLICE  10

void thandler()
{ 
    int i, x, y;
    PROC *p; TNODE *tp; PROC *newQ;
     
    tick++; tick %= 60;
    // except P0 which has no time limit
    if (running->pid && running->inkmode==1){
        running->time--;
        running->cpu++;
        if (running->cpu > 127)
	   running->cpu = 127;
    }
    if (tick == 0){
       sec++; sec %= 60;
       if (sec == 0){
          min++; min %= 60;
          if (min  == 0){
              hr++;
	      if (hr == 24){
		hr = 0;
		day++;
	      }
	  }
       }


       /****************** FD motor control part *********************/
       if (motor_status & 0x10){  // if FD motor is running
          fd_motor_off--;          // count down fd_motor_off from 120
          if (fd_motor_off <= 0){
             motor_status = 0x0C;   // turn off FD motor
	     out_byte(0x3F2, motor_status);
          }
       }
       if (tout==0){              // if task blocked on fdd
          fd_timeout--;            // count down on fd_timeout
          if (fd_timeout == 0){
              tout = 1;              // set timeout flag (also stop count down)
              V(&fdsem);             // unblock process in fd driver
          }
       }
       // each second: update btime[4,5,6] with hr, min, sec
       btime[6] = ((sec / 10) << 4) + (sec % 10);
       btime[5] = ((min / 10) << 4) + (min % 10);
       btime[4] = ((hr  / 10) << 4) + (hr  % 10);
 

       /******************* Wall clock part **************************/
       /* display wall clock, write to VGA memory directly */
       wall[7] = '0'+ (sec % 10); wall[6]='0'+ sec/10;
       wall[4] = '0'+ (min % 10); wall[3]='0'+ min/10;
       wall[1] = '0'+ (hr % 10);  wall[0]='0'+ hr/10;
       for (i=0; i<8; i++){
            w = wall[i];
            w = w | 0x0E00;
            put_word(w, 0x800B8000, org + 2*(24*80 + 70+i) );
       }
 
       /************ process sleepers every second ***************/
       for (i=0; i<NPROC; i++){
         p = &proc[i];
	 if (p->status==SLEEP && p->event==PAUSE){
	   p->pause--;
           printf("%d", p->pause);
           if (p->pause <= 0){
 	     //can't kwakeup(PAUSE) because this would wakeup all on PAUSE
             // must take p out of sleepList and make it READY
             outSleep(p);
             p->status = READY;
             p->event = 0;
             p->pri = 256 - p->cpu;
             schedule(p);
             printf("wakeup %d\n", p->pid);
	   }
	 }
       }  
       /********* processing timer queue elements *****************/
       if (tq){ // do these only if tq not empty
	  printTQ();
          tp = tq;
          while (tp){
             tp->time--;
             if (tp->time <= 0){ // send SIGALRM = 14
                 tp->who->res->signal |= (1 << 14);
                 tq = tp->next;
                 put_tnode(tp);
                 tp = tq;
             }
             else{
                   break;
	     }
	  }
       }
    }
    // at each QUANTA ticks, recompute process priority: must be <= runtime
    if ((tick % QUANTA) == 0){ 
       for (i=0; i<NPROC+NTHREAD; i++){
            p = &proc[i];
	    if (p->status != FREE && p->status != ZOMBIE){ // a valid PROC
	       if (p->pid)  // never change P0's priority or CPU time
	          if (p->cpu==0)
 	              p->pri = p->pri + SLICE;
                  else{
                      p->pri -= (p->cpu); // p->time max = 127 
	              p->cpu = 0;
	          }
	    }
       }

       // then reorder the readyQueue
       newQ = 0;
       while( p = (PROC *)dequeue(&readyQueue) ){
            enqueue(&newQ, p);
       }
       readyQueue = newQ;

       if (running->inkmode==1){
           running->pri -= running->cpu; // use Umode priority
       }

       if (readyQueue && (running->pri < readyQueue->pri)){
	  //printQueue(readyQueue);
	  //printf("PRIORITY:%d[%d] -> %d[%d]\n", running->pid, running->pri,
	  //       readyQueue->pid, readyQueue->pri);
          sw_flag = 1;
       }
       // reschedule if time up OR readyQ has higher prioirty procs
      //if (running->time<=0 || (readyQueue && readyQueue->pri > running->pri)){
  
       if (running->time<=0){
          //****** uncomment to see task switch by time slice
          //printf("TIMER:[%d-> %d]\n", running->pid, readyQueue->pid);
          sw_flag = 1;       // turn on rw_flag for rescheduling
       }
    }
    out_byte(0x20, 0x20);
    out_byte(0xA0, 0x20);
}

/******************** timer service part of MTX ***************************/
TNODE *get_tnode()
{
    TNODE *tp;
    tp = ft;
    ft = ft->next;
    return tp;
}

int put_tnode(TNODE *tp)
{
    tp->next = ft;
    ft = tp;
}

int printTQ()
{
   TNODE *tp;
   tp = tq;

   printf("timer = ");

   while(tp){
      printf(" [%d, %d] ==> ", tp->who->pid,tp->time-1);
      tp = tp->next;
   }
   printf("\n");
}
int printTQ1()
{
   TNODE *tp;
   tp = tq;

   printf("timer = ");

   while(tp){
      printf(" [%d, %d] ==> ", tp->who->pid,tp->time);
      tp = tp->next;
   }
   printf("\n");
}

kitimer(int time)
{
    TNODE *t, *p, *q;
    int ps;

    //printf("%d in kitimer: time=%d\n", time);
    // CR between clock and this process
    ps = int_off();
    t = get_tnode();
    t->time = time;
    t->who = running;

    /******** enter into tq ***********/
    if (tq==0){
        tq = t;
        t->next = 0;
    }
    else{
          q = p = tq;
          while (p){ 
              if (time - p->time < 0) 
                  break;  
              time -= p->time;
              q = p;
              p = p->next;
          }
          if (p){ 
              p->time -= time;
          }
          t->time = time;
          if (p==tq){
              t->next = tq;
              tq = t;
          }
          else{
                t->next = p;
                q->next = t;
          }
    }

    //running->status = TIMER;
    int_on(ps);

    printTQ1();

    //    tswitch();
    // return to umode ==> will get SIGALRM when timer expires
}

