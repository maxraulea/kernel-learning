/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/***********************************************************************
                      io.c file of MTX
***********************************************************************/
#include "uinclude.h"

char *ctable = "0123456789ABCDEF";
char cr = '\r';

void align(u32 x)
{
  int count;
  count = 6;
  if (x==0) 
     count = 5;
  while (x){
    count--;
    x = (u32)(x/10);
  }

  while(count){
    putc(' ');
    count--;
  }
}

void rpi(int x)
{
   char c;
   if (x==0) return;
   c = ctable[x%10];
   rpi((int)x/10);
   putc(c);
}
  
void printi(int x)
{
    if (x==0){
       prints("0 ");
       return;
    }
    if (x < 0){
       putc('-');
       x = -x;
    }
    rpi((int)x);
    putc(' ');
}

void rpu(u32 x)
{
   char c;
   if (x==0) return;
   c = ctable[x%10];
   rpi((u32)x/10);
   putc(c);
}

void printu(u32 x)
{
    if (x==0){
       prints("0 ");
       return;
    }
    rpu((u32)x);
    putc(' ');
}

void rpx(u32 x)
{
   char c;
   if (x==0) return;
   c = ctable[x%16];
   rpx((u32)x/16);
   putc(c);
}

void printx(u32 x)
{  
  prints("0x");
   if (x==0){
      prints("0 ");
      return;
   }
   rpx((u32)x);
  putc(' ');
}

void prints(char *s)
{
   while (*s){
      putc(*s);
      s++;
   }
}

void printc(char c)
{
  putc(c);
  c = c&0x7F;
  if (c=='\n')
    putc(cr);
}

int printk(char *fmt,...)
{
  char *cp, *cq;
  int  *ip;

  cq = cp = (char *)fmt;
  ip = (int *)&fmt + 1;

  while (*cp){
    if (*cp != '%'){
       printc(*cp);
       cp++;
       continue;
    }
    cp++;
    switch(*cp){
      case 'd' : printi(*ip); break;
      case 'u' : printu(*ip); break;
      case 'x' : printx(*ip); break;
      case 's' : prints((char *)*ip); break;
      case 'c' : printc((char)*ip);   break;
    }
    cp++; ip++;
  }
}


int put2c(char c)
{
  write(2, &c, 1);
}

void print2s(char *s)
{
   while (*s){
      put2c(*s);
      s++;
   }
}

void align2(u32 x)
{
  int count;
  count = 6;
  if (x==0) 
     count = 5;
  while (x){
    count--;
    x = (u32)(x/10);
  }

  while(count){
    put2c(' ');
    count--;
  }
}

void rp2i(int x)
{
   char c;
   if (x==0) return;
   c = ctable[x%10];
   rp2i((int)x/10);
   put2c(c);
}
  
void print2i(int x)
{
    if (x==0){
       print2s("0 ");
       return;
    }
    if (x < 0){
       put2c('-');
       x = -x;
    }
    rp2i((int)x);
    put2c(' ');
}

void rp2u(u32 x)
{
   char c;
   if (x==0) return;
   c = ctable[x%10];
   rp2i((u32)x/10);
   put2c(c);
}

void print2u(u32 x)
{
    if (x==0){
       print2s("0 ");
       return;
    }
    rp2u((u32)x);
    put2c(' ');
}

void rp2x(u32 x)
{
   char c;
   if (x==0) return;
   c = ctable[x%16];
   rp2x((u32)x/16);
   put2c(c);
}

void print2x(u32 x)
{  
  prints("0x");
   if (x==0){
      print2s("0 ");
      return;
   }
   rp2x((u32)x);
  put2c(' ');
}


void print2c(char c)
{
  put2c(c);
  c = c&0x7F;
  if (c=='\n')
    put2c(cr);
}

int print2f(char *fmt,...)
{
  char *cp, *cq;
  int  *ip;

  cq = cp = (char *)fmt;
  ip = (int *)&fmt + 1;

  while (*cp){
    if (*cp != '%'){
       print2c(*cp);
       cp++;
       continue;
    }
    cp++;
    switch(*cp){
      case 'd' : print2i(*ip); break;
      case 'u' : print2u(*ip); break;
      case 'x' : print2x(*ip); break;
      case 's' : print2s((char *)*ip); break;
      case 'c' : print2c((char)*ip);   break;
    }
    cp++; ip++;
  }
}
