/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
// MTX's HD block size = 1KB ==> need mgetBlk() and MBLK

#define MBLK       1024
#define BOOTSEG  0x9800

u8 btime[8]; // centry, year, month, day, bhr, bmin, bsec, bpad;

u16 mgetBlk(blk, buf) u32 blk; char *buf;
{
  dp->addr = (u16)buf;
  dp->s1 = (u32)(bsector + (u32)(2*blk));
  diskr();
}

u32 msearch(ip, name) INODE *ip; char *name;
{
   u16  i, k; 
   char *cp;
   DIR  *dirp; char temp[256];
  
   for (i=0; i<12; i++){
     if (ip->i_block[i]==0)
       return 0;

     mgetBlk((u32)ip->i_block[i], b2);
   
     dirp = (DIR *)b2;
     cp = b2;
     k = 0;

     while (cp < &b2[MBLK]){
        strncpy(temp, dirp->name, dirp->name_len);
        temp[dirp->name_len] = 0;

        prints(temp); putc(' ');
        k += (dirp->name_len + 1);
        if (k > 64){
	  prints("\n\r"); k = 0;
        }
        if ( strcmp(temp, name) == 0 ){
           printf("\nFOUND %s:\n", name);
           return((u32)dirp->inode);
        }
        cp += dirp->rec_len; 
        dirp = (DIR *)cp;
     }
   }
   return(0);
}

int ptime(t) u8 t[8];
{
   printf("date=%c%c%c%c-%c%c-%c%c  ",

          (t[0]>>4)+'0', (t[0]&0x0F)+'0',
          (t[1]>>4)+'0', (t[1]&0x0F)+'0', 
          (t[2]>>4)+'0', (t[2]&0x0F)+'0',
          (t[3]>>4)+'0', (t[3]&0x0F)+'0'
	  /***********
          (t[7]>>4)+'0', (t[7]&0x0F)+'0',
          (t[6]>>4)+'0', (t[6]&0x0F)+'0', 
          (t[5]>>4)+'0', (t[5]&0x0F)+'0',
          (t[4]>>4)+'0', (t[4]&0x0F)+'0'
	  ****************/
         );
   printf("time=%c%c:%c%c:%c%c\n",

          (t[4]>>4)+'0', (t[4]&0x0F)+'0',
          (t[5]>>4)+'0', (t[5]&0x0F)+'0', 
          (t[6]>>4)+'0', (t[6]&0x0F)+'0'
	  /************	  
          (t[3]>>4)+'0', (t[3]&0x0F)+'0',
          (t[2]>>4)+'0', (t[2]&0x0F)+'0', 
          (t[1]>>4)+'0', (t[1]&0x0F)+'0'
	  ***********/	  
         );
}



int bootMtx(pno, bootsector) u16 pno; u32 bootsector;
{ 
  u16   i, *tp;
  u32   me, blk, *up;
  char  *cp, filename[64];
  INODE *ip;
  DIR   *dirp;

  // initialize dap
  dp = &dap;
  dp->len = 0x10;
  dp->zero = 0;
  dp->nsector = 2;             // 1KB block sizes
  dp->segment = BOOTSEG;
  dp->s2 = 0;
  color = RED;

  printf("\n\n*************  KCW's PMTX  booter : ***************** \n");  
  prints("partition="); printd(pno);

  bsector = bootsector;
  printf("bsector = %l\n", (u32)bsector);

  // read SUPER block to get BLK size and inodes_per_group
  mgetBlk((u32)1, b1);
  sp = (SUPER *)b1;     // super block is aways at 1024 bytes
  blksize = 1024* (1 << sp->s_log_block_size);
  pginodes = sp->s_inodes_per_group;
  pgblks = sp->s_blocks_per_group;

  // read GD block to get inode start block
  mgetBlk((u32)2, b1); 
  gp = (GD *)b1;
  inodeBlk = gp->bg_inode_table;
 
  printf("blk_size=%d inodes_pg=%d blocks_pg=%d inodes_table=%d \n", 
          blksize, (u16)pginodes, (u16)pgblks, (u16)inodeBlk);

  mgetBlk((u32)inodeBlk, b1);
  ip = (INODE *)b1 + 1;

  /* serach for system name */

  printf("Enter name to boot (ENTER=/boot/mtx) : ");
  kgets(path);

  bootname = path;
  if (path[0]==0)
    bootname = "/boot/mtx";
 
  color = GREEN;
  printf("Search for %s\n", bootname);

  tokenlize(bootname);
  for (i=0; i<nn; i++)
    printf("%s ", name[i]);

  //  getc();

  for (i=0; i<nn; i++){
    printf("%d : serach for %s\n", i, name[i]);
     me = msearch(ip, name[i]);
     if (me == 0){
        printf("\nSorry! can't find %s\n", name[i]); 
        return(0);
     }
     me--;

     group   = me / pginodes;
     inumber = me % pginodes;
   
     blk  = inumber / (blksize/128);
     disp = inumber % (blksize/128);

     // KCW: can't use groups*blocks_per_group to get group's inodesStart
     //blk = blk + (u32)(group*pgblks);
     //prints("gp inodesStart="); printf("(ulong)(group*pgblks));

    // read GD to get gp->bg_inode_table
     mgetBlk((u32)2, b2);
     gp = (GD *)b2 + group;
     blk += gp->bg_inode_table; 

     mgetBlk((u32)blk, b1);      /* read block inode of me */
 
     ip = (INODE *)b1;
     ip += disp;

     printf("ino=%l  group=%l  blk#=%l  inum=%l  size=%l\n",
             (u32)(me+1), (u32)group, (u32)blk, (u32)disp, (u32)ip->i_size);
  }
  prints("Loading ");

  /* read indirect block into b2 */
  if (ip->i_block[12]) 
      mgetBlk((u32)ip->i_block[12], b2);

  // load MTX image to 0x1000
  /*******************************************************************
   pmtx image = S0+SETUP in block 0
   MTX kernel begins from block1
  *******************************************************************/

  printf("BOOT+SETUP to 0x9000\n");  

  dp->segment = 0x9000;
  mgetBlk((u32)ip->i_block[0],0);
  getc();

  printf("apentry to 0x9100\n");  
  dp->segment = 0x9100;
  mgetBlk((u32)ip->i_block[1],0);

  printf("pmtx to 0x1000\n");  
  dp->segment = 0x1000;

  for (i=2; i<12; i++){
     printf("%l ", (u32)ip->i_block[i]);
     mgetBlk((u32)ip->i_block[i], 0);
     dp->segment += 0x40;  
     putc('*');
  } 

  /* load indirect blocks */
  up = (u32 *)b2;         /* access b2[] as u32s */
  while(*up){
     printf("%d ", (u16)*up);
     mgetBlk((u32)*up, 0); 
     dp->segment += 0x40;       
     up++;
     putc('.');
  }
  put_word(pno, 0x1000, 8); /* put partition# into offset 8 in MTX image */

  biostime();
  tp = (u16 *)btime; 
  ptime(btime); 

  // write BIOS time to 0x9000 for MTX kernel to get
  for (i=0; i<8; i++)
    put_byte(btime[i],0x9000, i);
  
  printf("\nready?"); getc();
  i=get_word(0x9000, 510);
  if (i==0x5252)
     goreal();
  gomtx((u32)bootsector);
}  

