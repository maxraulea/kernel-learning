/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/******************** bootLinux.c file *******************************/
#define BLK 4096

/* Under Linux, bcc's #include dir = /usr/lib/bcc/include  */
/* <linux/ext2_fs.h> contains ext2_fs types */

#include "linux.h"
/*
typedef struct ext2_super_block SUPER;
typedef struct ext2_group_desc  GD;
typedef struct ext2_inode       INODE;
typedef struct ext2_dir_entry_2 DIR;
*/
SUPER *sp;
GD    *gp;
INODE *ip;
DIR   *dirp; 

char b1[BLK], b2[BLK], b3[BLK];   // disk I/O buffers
char *bootname, path[128];        // boot filename

u16  blksize, pcount, ecount;
u16  bzImage = 0;     // big kernel flag
u16  inode_size, inode_ratio, inodepbk;  // NEW ext2_fs inode_size may be 256
u16  inodepg, blkpg, descpbk; //inodes_per_group, blk_per_group, descs_per_block
u16  gdblk, gdisp;

u32  bsector, inodeBlk, group, inumber, disp, pginodes, pgblks;
u32  lastaddr;        // for debugging loading address
u32  firstdblk;       // first_data_block

INODE  rinode, *rip;   /* saved root inode and pointer */

u16 getblk(blk, buf, nblk) u32 blk; char *buf; u16 nblk;
{
  printf("getblk: %l %x %d  ", blk,buf,nblk);
  dp->nsector = nblk*8;  // nsector MUST <= 127, so nblks=16 would fail 
  dp->addr = (u16)buf;
  dp->s1 = (u32)(bsector + (u32)(8*blk));
  diskr();
  printf("done\n");
}

struct vmgdt
{
  u32 zeros[4];  // 16 bytes 0's for BIOS to use
  // src = real-mode address
  u16 rm_limit;      // 0xFFFF
  u32 rm_addr;       // 0x 00 00 01 93
  u16 rm_hiword;     // 0 
  // dest = high-mem address
  u16 vm_limit;     // 0xFFFF
  u32 vm_addr;      // 0x 00 00 10 93
  u16 vm_hiword;    // 0
  // BIOS CS DS
  u32 bzeros[4];    // 0
} vm_gdt, *gdtp;


init_vm_gdt()
{
  int i;
  gdtp = &vm_gdt;
  for (i=0; i<4; i++){
      gdtp->zeros[i] = gdtp->bzeros[i] = 0;
  }  
  gdtp->rm_limit= gdtp->vm_limit = 0xFFFF;
  gdtp->rm_addr = 0x93010000;  // 0x00 00 01 93
  gdtp->vm_addr = 0x93100000;  // 0x00 00 10 93
  gdtp->rm_hiword = gdtp->vm_hiword = 0x0093;
}

int cp_vm(nblk, ch) u16 nblk; char ch;
{
  //ushort nwords = nblk*2048;   // 2-byte words to copy
  cp2himem(nblk*2048);           
  if (nblk<16)
     gdtp->vm_addr += (u32)( (u32)nblk* (u32)4096);
  else
    gdtp->vm_addr += (u32)0x10000;  // aovid overflow u16
  putc(ch);
} 

int load(ip, startblk) INODE *ip; u16 startblk;
{
  int i,j,k;
  u32 *up;

  i = startblk;
  while(i<12){ // continue to load (i<12) direct blocks
    k = 1;
    for (j=i+1; j<12; j++){  // look for k consecutive blocks
      if ((ip->i_block[i] + j-i) == ip->i_block[j])
	k++;
    }
    getblk((u32)ip->i_block[i], 0, k);  // load k conse.blocks 
    cp_vm(k, '*'); 
    i += k;
  }
 
  up = (u32 *)b2;

  while(*up){
    k = 1;
    /********** try to load k < 16 consec. blocks at a time ********
     dap->nsectors must be 1 to 127; k=16 => 16*6 would exceed 127
    ****************************************************************/
    for (j=1; j<15; j++){  // load max. 15 blocks 
      if ((*up + j) == *(up+j))
	k++;
    }
    getblk((u32)*up, 0, k);
    cp_vm(k, '.');
    up += k;
  }
}
  
/************************************************************************
 tokenlize() breaks up a pathname into component strings.
 Example : pathname = /this/is/a/test
 Then n=4, name[0] ="this", name[1] ="is", name[2] ="a",name[3] ="test" 
 The component names are used to search for a child under its parent
*************************************************************************/
u16   nn;
char *name[32];

int tokenlize(path) char *path;
{
  int i;
  char *cp;
  cp = path;
  nn = 0;
  
  while (*cp != 0){
       while (*cp == '/') *cp++ = 0;        
       if (*cp != 0)
           name[nn++] = cp;         
       while (*cp != '/' && *cp != 0) cp++;                  
       if (*cp != 0)   
           *cp = 0;                   
       else 
            break; 
       cp++;
  }
  /********
  printf("n = %d : ", nn);
  for (i=0; i<nn; i++)
       printf("  %s  ", name[i]);
  printf("\n");
  **********/
}

u32 search(ip, name) INODE *ip; char *name;
{
   u16  i, k; 
   char *cp, c;
   DIR  *dirp; char temp[256];
  
   for (i=0; i<12; i++){ // assume : DIR has only direct blocks
     if (ip->i_block[i]==0)
       return 0;
     getblk((u32)ip->i_block[0], b2, 1);
   
     dirp = (DIR *)b2;
     cp = b2;
     k = 0;

     while (cp < &b2[BLK]){
        // save last char of dirp->name
        c = dirp->name[dirp->name_len];
        // make dirp->name into a string
        dirp->name[dirp->name_len] = 0;
        printf("%s ", dirp->name);
        k += (dirp->name_len + 1);
        if (k > 64){
	  printf("\n"); k = 0;
        }
        if ( strcmp(dirp->name, name) == 0 ){
           printf("\nFOUND %s\n", name);
           return((u32)dirp->inode);
        }
        // restore last char of dirp->name
        dirp->name[dirp->name_len] = c; 

        cp += dirp->rec_len; 
        dirp = (DIR *)cp;
     }
   }
   return 0;
}

u8  low, high, c;
u16 setup_sectors, setupBlks, sBlks;
u16 sSectors, kSectors;

INODE *get_inode(filename) char *filename;
{
  u16    i;
  u32    ino, blk, *up;
  INODE *ip;

  color = GREEN;
  printf("Search for %s\n", filename);

  tokenlize(filename);
  
  ip = rip;

  for (i=0; i<nn; i++){
     printf("%d : serach for %s\n", i, name[i]);
     ino = search(ip, name[i]);
     if (ino == 0){
        printf("\nSorry! can't find %s\n", name[i]); 
        return 0;
     }
     ino--;
     // convert me to its group# and offset# in that group 
     group   = ino / inodepg;
     inumber = ino % inodepg;

     // a block contains only 4096/32=128 GDs. For LARGE group#, it may exceed 
     // one GD block => must figure out which block and offset in that block.
     gdblk = group / descpbk;      // which block this GD is in
     gdisp = group % descpbk;      // which GD in that block

     blk  = inumber / inodepbk;    // blk# relative to this group's inode_table
     disp = inumber % inodepbk;    // inode offset in that block
  
     // read GD to get gp->bg_inode_table
     getblk((u32)(1+firstdblk+gdblk), b2, 1);
     gp = (GD *)b2 + gdisp;        // this group desc.

     blk += gp->bg_inode_table;   // blk is relative to group's inode_table 

     getblk((u32)blk, b1, 1);     // read the inode block of me */
 
     ip = (INODE *)b1;           
     ip += (disp*inode_ratio);    // this is the inode struct of me

     printf("ino=%l  group=%l  blk#=%l  inum=%l  0x%X\n",
           (u32)(ino+1), (u32)group, (u32)blk, (u32)disp, (u32)ip->i_size);
     getc();
  }
  color = RED;
  return ip;
}

u32 rdaddress, rdsize;

/************************** KCW: 11-2010 **************************
 initrd.gz loaded at 16MB worked fine for slackware prior to 3.0
 for slackware 3.1, which uses kernel 2.6.33.3, setup would not even start
 but boot huge image without initrd image works fine ==> pin point to 
 load_rd() problem.
 suspect the loading address 16MB is too low. so, increased it to 32MB
 and it booted fine
********************************************************************/

int load_rd()
{
  u32   *up;
  INODE *ip;

  dp->segment = BOOTSEG; // MUST set dp->segment to DS again

  // set vm_addr to initrd's loading address at 16MB
  // KCW: load_rd() doe snot work for slackware 3.1, try 32MB
  gdtp->vm_addr   = 0x93000000 | 0x00000000;
  //gdtp->vm_hiword = 0x0193; // load to 16M

  /************ changed loading address to 32MB ********************/
  //gdtp->vm_hiword = 0x0293; // load to 32M
  gdtp->vm_hiword = 0x0493; // load to 32M
 
  printf("\nEnter initrd pathname (ENTER=/initrd.gz) : ");
  kgets(path);

  bootname = path;
  if (path[0]==0)
    bootname = "/initrd.gz";

  if (!(ip = get_inode(bootname)))
     return 0;
     
  color = RED;

  rdsize = ip->i_size;

  printf("Loading image size=%l bytes\n", ip->i_size);
  color = GREEN;

  getblk((u32)ip->i_block[12], b2, 1);

  if (ip->i_block[13]){
    getblk( (u32)ip->i_block[13], b3, 1);
    up = (u32 *)b3;
    getblk((u32)(*up), b3, 1);
  }

  // load initrd image is easy, just load blocks to 0x1000, then cp2himeme()

  dp->segment = 0x1000;

  load(ip, 0);  // start block# = 0

  color = RED;

  // write initrd address LONG 0x800000 to (0x9020,24) 
  //       initrd size    LONG          to (0x9020,28)
  //  rdaddress = 0x01000000;   // 16MB

  /******** changed loading address ot 32MB *************/
  //rdaddress = 0x02000000;   // 32MB
  rdaddress = 0x04000000;   // 64MB

  put_word((u16)rdaddress, 0x9020, 24);
  put_word((u16)(rdaddress >> 16), 0x9020, 26);
  put_word((u16)rdsize, 0x9020, 28);
  put_word((u16)(rdsize >> 16), 0x9020, 30);

  return 1;
}

char slink[1024];

int bootLinux(pno, pbsector) u16 pno; u32 pbsector;
{ 
  u16   i, rdev, rootdev;
  u32   me, blk, *up;
  INODE *ip;

  getc();

  // initialize dap
  dp = &dap;
  dp->len = 0x10;
  dp->zero = 0;
  //  dp->nsector = 8;             // 4KB block size
  dp->nsector = 8;             // 4KB block size
  dp->segment = BOOTSEG;
  dp->s2 = 0;

  // initilize GDT
  init_vm_gdt();

  color = RED;
  rdev = pno; bsector = pbsector;  // set globals rdev and bsector

  printf("*****************  KCW booter : ***************** \n");  
  printf("boot linux from partition=%d  bsector=%l\n", pno, bsector);


  // read SUPER block to get BLK size and inodes_per_group
  getblk((u32)0, b1, 1);
  sp = (SUPER *)&b1[1024];    // super block is aways at 1024 bytes

  // check whether it's ext2/ext3 FS
  if (sp->s_magic != 0xEF53){
    printf("partition %d is not an ext2/ext3 file system\n");
    return 0;
  }

  blksize = 1024* (1 << sp->s_log_block_size);
   
  firstdblk = sp->s_first_data_block; 
  pginodes = sp->s_inodes_per_group;
  pgblks = sp->s_blocks_per_group;

  inodepg = sp->s_inodes_per_group;
  blkpg   = sp->s_blocks_per_group; 
  descpbk  = blksize/sizeof(GD);

  inode_size = sp->s_inode_size;
  inode_ratio = sp->s_inode_size/sizeof(INODE);
  inodepbk = blksize/inode_size;

  printf("inode_size=%d inode_ratio=%d\n", inode_size, inode_ratio);
  getc();
  // read GD block to get inode start block

  getblk((u32)(firstdblk+1), b1, 1); 
  gp = (GD *)b1;            
  inodeBlk = gp->bg_inode_table;
 
  printf("blk_size=%d inodes_pg=%d blocks_pg=%d inodes_table=%d \n", 
          blksize, (u16)pginodes, (u16)pgblks, (u16)inodeBlk);

  getc();

  getblk((u32)inodeBlk, b1, 1);
  ip = (INODE *)b1 + (1*inode_ratio);

  // save root inode struct in rinode pointed by rip
  rip = &rinode; // let rip->saved root inode, need it for loading initrd
  *rip = *ip;

  // now the real linux kernel loading part begins
  printf("Enter kernel name to boot (ENTER=vmlinuz) : ");
  kgets(path);

  bootname = path;
  if (path[0]==0)
     bootname = "/vmlinuz";
 dolink:
  if (!(ip = get_inode(bootname)))
      return 0;  // to bc.c for loading Linux error

  color = RED;
  if ((ip->i_mode & 0120000)==0120000){
    printf("symlink -> %s\n", (char *)ip->i_block);
    if (ip->i_size < 256){
      if (*(char *)ip->i_block == "/")
          slink[0] = 0;
      else{
	  strcpy(slink, "/");
          for (i=0; i<nn-1; i++){
	    strcat(slink, name[i]);
            strcat(slink, "/");
          }
      }
      strcat(slink, (char *)ip->i_block);
    }
    bootname = slink;
    getc();
    goto dolink;
  }

  bzImage = 1; // BIG kernel flag, default here
  if (ip->i_size > (u32)8*64*1024){
    printf("booting BIG kernel image\n");
  }
  else{
    printf("this booter can't boot SMALL kernel image\n");
    return 0;
  }
  color = GREEN;
  /* read indirect block into b2 */
  getblk((u32)ip->i_block[12], b2, 1);

  if (ip->i_block[13]){
    getblk( (u32)ip->i_block[13], b3, 1);
    up = (u32 *)b3;
    getblk((u32)(*up), b3, 1);
  }

  // load image's B0 to 0x9000; 
  dp->segment = 0x9000;
  getblk((u32)ip->i_block[0], 0, 1);

  // loading Linux kernel is a pain if SETUP is NOT a multiple of blocks.
  // it would be much better if setup_sectors is a multiple of block size, 
  // e.g. 16, 24, 32, etc. for 4KB BLKSIZE. 
  // Also, in 2.6 kernel, setup_sectors in build includes the entire SETUP
  // but recorded value at offset 497 is 1 less, which is confusing!!!

  // read setup_sectors at 497 (value NOT including bootsector)
  setup_sectors = get_word(0x9000, 496) >> 8;  // need this first
  setupBlks = (setup_sectors + 1 + 7)/8; 
  sBlks    = (setup_sectors + 1) / 8;
  sSectors = (setup_sectors + 1) % 8;
  printf("setup_sectors=%d  setupBlks=%d  ", setup_sectors, setupBlks);
  printf("sBlks=%d  sSectors=%d\n", sBlks, sSectors);
 
  dp->segment += 0x100;  
  for (i=1; i<setupBlks; i++){
      getblk((u32)ip->i_block[i], 0, 1);
      dp->segment += 0x100;
  }
  // In i_block[sBlk], first sSectors are SETUP, remaining are kernel
  // this is really a pain in the ass, absolutely insane!!!.

  if (setupBlks > sBlks){ // they differ by at most 1
     kSectors = 8 - sSectors;
     dp->segment = 0x1000 - sSectors*0x20;
     getblk((u32)ip->i_block[setupBlks - 1], 0, 1);
     cp2himem(2048);
     gdtp->vm_addr += kSectors*512;
  }

  // from here on, load blocks to 0x1000, then cp2himem() to high memory
  dp->segment = 0x1000;
 
  load(ip, setupBlks);  // start block# = setupBlks
   
  color = RED;
  lastaddr = gdtp->vm_addr & 0x00FFFFFF;
  printf("\nhighest kernel loading addrress = 0x%X\n", (u32)lastaddr);
  
  printf("fix boot parameters in BOOT and SETUP\n");

  /*********************************************************************
   BOOT (0x9000)                 
   offset  size                  contents
  -------  ----   ----------------------------------------------------    
    497     u8    setup_sects;	 // number of SETUP sectors
    498    u16    root_flags;	 // mount rootdev readonly if non-zero
    506    u16    vidmode        // video mode, e.g. 773 for small fonts 
    508    u16    root_dev;      // root device (major,minor) number
  ---------------------------------------------------------------------
   SETUP (0x9020)
     16     u8    type_of_loader;// NEW boot_loader ID   : must be 0x20
     18     u8    loadflags;     // kernel load high flag: must be 0x01
     24    u32    ramdisk_image; // initrd loaded real address 
     28    u32    ramdisk_size;  // initrd's size in bytes     
  *********************************************************************/
   // set vidmode to 773 (small fonts) 
  put_word(773, 0x9000, 506); 
  //read and patch root dev [minor,major] in [508,509]
  rootdev = get_word(0x9000,508);
  printf("original root=[%x %x] ", rootdev>>8, rootdev & 0x00FF);
  // patch in [root_minor, root_major] at [508,509]
  //  rootdev = (0x03 << 8) + rdev;
 
  // KCW:slackware 13.1 uses /dev/sda instead of /dev/hd
  // /dev/sda8 = 0x0808
  // rootdev = (0x08 << 8) + rdev;  
  rootdev = (0x03 << 8) + rdev;     // assume IDE HD 0x03--  
  put_word(rootdev, 0x9000, 508);
  printf("new root=[%x %x]\n", rootdev>>8, rootdev & 0x00FF);

  if (bzImage)   // MUST set these flags or else SETUP code would reject & die
     put_word(0x2001, 0x9020, 16);   // SETUP:18,16 = NEW_booter, LOAD_HIGH=1

  printf("load initrd (y|n) ? ");
  if ( (c=getc()) != 'n')
     load_rd();

  printf("\nready to go?"); getc();
  jmp_setup();

}  
