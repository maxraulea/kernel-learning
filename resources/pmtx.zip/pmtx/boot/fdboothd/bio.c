/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/*********************************************************************
               bio.c file of HD linux booter
*********************************************************************/
u16 ALIGN = 1;

int align(x) u32 x;
{
  int digits, count, i;
  digits = 0;
  while (x){
    digits++;
    x = x /10;
  }                 

  //  if (digits <= 4)
  //  count = 4-digits;
  // else
    count = 10-digits;
  while(count>0){
    putc(' ');
    count--;
  }
}

char *tab="0123456789ABCDEF";
int  BASE = 10;

int rpl(x) u32 x;
{
  char c;
  if (x==0)
    return;
  c = tab[x % BASE];
  rpl(x / BASE);
  putc(c);
}

int printl(x) u32 x;
{
  if (ALIGN)    // global 0 => no alignment
      align(x);
  if (x==0){
    putc('0'); putc(' ');
    return;
  }
  rpl(x);
  putc(' ');
}

int rpu(x) u16 x;
{
  char c;
  if (x==0)
    return;
  c = tab[x % BASE];
  rpu(x / BASE);
  putc(c);
}

int printu(x) u16 x;
{
  if (x==0){
    putc('0'); putc(' ');
    return;
  }
  rpu(x);
  putc(' ');
}

int printd(x) int x;
{
  if (x<0){
    putc('-');
    x = -x;
  }
  printu(x);
}

int printx(x) u16 x;
{
  BASE = 16;
  printu(x);
  BASE = 10;
}

int printX(x) u32 x;
{
  BASE = 16;
  printl(x);
  BASE = 10;
}

int prints(s) char *s;
{
   while(*s){
       putc(*s);
       s++;
   }
}

int printf(fmt) char *fmt;
{
  char   *cp;
  u16    *ip;
  u32    *up;
 
  cp = fmt;
  ip = (int *)&fmt + 1;

  while (*cp){
    if (*cp != '%'){
      putc(*cp);
      if (*cp=='\n')
	putc('\r');
      cp++;
      continue;
    }
    cp++;
    switch(*cp){
      case 'c' : putc  (*ip); break;
      case 's' : prints(*ip); break;
      case 'u' : printu(*ip); break;
      case 'd' : printd(*ip); break;
      case 'x' : printx(*ip); break;
      case 'l' : printl(*(u32 *)ip++); break;  // print long value in decimal
      case 'X' : printX(*(u32 *)ip++); break;  // print long value in hex
    }
    cp++; ip++;
  }
}

#define LEN 64
int kgets(s) char *s;
{ 
  char c, *b; int n = 0;
  b = s;
  while ( (c=getc()) != '\r' && n < LEN){
      if (c=='\b'){
         if (s==b)
            continue;
         s--;
         putc('\b'); putc(' '); putc('\b');
         continue;
      }   
      *s = c;   
      putc(*s); s++; n++;
  }
  *s = 0;
   prints("\n\r");
}

int get_word(segment, offset) u16 segment, offset;
{
  u16 word;
  setds(segment);
  word = *(u16 *)offset;
  setds(0x9800);
  return word;
}

int put_word(word, segment, offset) u16 word, segment, offset;
{
  setds(segment);
  *(u16 *)offset = word;
  setds(0x9800);
}

int put_byte(byte, segment, offset) u16 byte, segment, offset;
{
  setds(segment);
  *(u8 *)offset = byte;
  setds(0x9800);
}

