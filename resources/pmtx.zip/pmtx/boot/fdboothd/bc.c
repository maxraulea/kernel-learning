/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

#define MAXPART 10         // max. number of HD partitions
#define  GREEN  10         // color byte for putc()
#define  CYAN   11
#define  RED    12
#define  MAG    13
#define  YELLOW 14


struct partition {         // Partition table entry in MBR
       u8  drive;          // 0x80 - active 
       u8  head;	   // starting head 
       u8  sector;	   // starting sector 
       u8  cylinder;       // starting cylinder 
       u8  type;	   // partition type 
       u8  end_head;       // end head 
       u8  end_sector;	   // end sector 
       u8  end_cylinder;   // end cylinder 
       u32 start_sector;   // starting sector counting from 0 
       u32 nr_sectors;     // nr of sectors in partition 
};

struct dap{                // DAP for extended INT 13-42  
       u8   len;           // dap length=0x10 (16 bytes)
       u8   zero;          // must be 0  
       u16  nsector;       // number of sectors to read: 1 to 127
       u16  addr;          // memory address = (segment:addr)
       u16  segment;    
       u32  s1;            // low  4 bytes of sector#
       u32  s2;            // high 4 bytes of sector#
};

struct dap dap, *dp;       // global dap struct
u16   color = CYAN;        // initial color for putc()

#define  BOOTSEG 0x9800
#include "bio.c"
#include "bootLinux.c"
#include "bootMtx.c"

struct hd_part{            // HD partition records
  u8   type;
  u32  start_sector;
  u32  size;
} hd[MAXPART];

char *ptype(t) int t;
{
  char *s = "Other";
  if (t==0x05) s="Extnd";
  if (t==0x06) s="Fat16";
  if (t==0x07) s="Ntfs ";
  if (t==0x0b) s="Fat32";
  if (t==0x0c) s="Fat32";
  if (t==0x0f) s="WnExt";
  if (t==0x81) s="Minix";
  if (t==0x82) s="LSwap";
  if (t==0x83) s="Linux";
  if (t==0x90) s="MTX  ";

  return s;
}

u32   Esector, esector; 
char  mbr[512], Ebuf[512];
u16   n, EXT=0;
u16   *uip;

// load a disk sector to (DS, addr)
int getSector(sector, addr) u32 sector; char *addr;
{
  dp->addr    = addr;
  dp->s1      = (u32)sector;
  diskr();    // call int13-43 in assembly
}

int main()
{
  int i, j;
  struct partition *p, *ep;

  //  resetVideo();

  // initialize the dap struct
  dp = &dap;
  dp->len  = 0x10;        // must be 16
  dp->zero = 0;           // must be 0
  dp->nsector = 1;        // load one sector
  dp->addr = 0;           // will set to addr              
  dp->segment = BOOTSEG;  // always booter's segment
  dp->s1 = 0;             // will set to LBA sector#
  dp->s2 = 0;             // high 4-byte address s2=0

  getSector((u32)0, (u16)mbr);

  p = (struct partition *)(&mbr[0x1be]);
  printf("p#  type    start_sector  nr_sectors\n");
  printf("------------------------------------\n");

  for (i=1; i<=4; i++){
    hd[i].type = p->type;
    hd[i].start_sector = p->start_sector;
    hd[i].size = p->nr_sectors;
    printf("%d  %s  %l  %l\n", i, ptype(p->type), 
                               p->start_sector, p->nr_sectors);
    if (p->type==5)
        EXT = i;
    p++;
  }
   
  ecount = 0;
  if (EXT){
    printf("-------- EXTEND Partitions ---------\n");
    esector = Esector = hd[EXT].start_sector;
    getSector(esector, Ebuf);
    p = &Ebuf[0x1be];
    while(1){
        hd[i].type = p->type;
        hd[i].start_sector = esector + p->start_sector;
        hd[i].size = p->nr_sectors;

        printf("%d  %s  %l  %l\n", i, ptype(hd[i].type), 
	       (u32)(hd[i].start_sector), (u32)hd[i].size);
        p++; i++; ecount++; 
        if (p->start_sector == 0)
	  break;
        esector = Esector + p->start_sector;
        getSector(esector, Ebuf);     
        p = &Ebuf[0x1BE];
    }
  }
  printf("------------------------------------\n");
  pcount = i-1; 

  ALIGN = 0;   // turn off alignment in printl()

  while(1){
    printf("Enter Boot Partition # : ");
    c = getc(); // assume partitions 1 to 9
    putc(c); printf("\n");
    n = c - '0';
    if ( n > pcount){
       printf("P%d:  out of range\n", n);
       continue;
    }
    if (hd[n].type == 5){
        printf("can't boot from EXTEND partition %d\n", n);
        continue;
    }
    if (hd[n].type == 0x90 || hd[n].type==0x81){
      printf("boot MTX\n");
      bootMtx(n, (u32)hd[n].start_sector);
    }
    if (hd[n].type == 0x83){
      printf("boot Linux partition P%d\n", n);
      if (!bootLinux(n, (u32)hd[n].start_sector))
         continue;
    }
    printf("P%dis not a Linux/MTX partition, chain-boot? (y|n)",n);
    c=getc(); putc(c); printf("\n");
    if (c != 'y')
	 continue;
    printf("chain-boot from P%d local MBR\n", n);
    // load partition's MBR to 0x0000:0x7C00 and jump to it
    dp->addr = (u16)0x7C00;
    dp->segment = 0;
    dp->nsector = 1;
    dp->s1 = hd[n].start_sector;
    diskr();
    return 1; // to bs.s:  jmpi 0x7C00,0x0000
  }
}
