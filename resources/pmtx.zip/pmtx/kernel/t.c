/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/********************* 2-1-11 **************************
                     t.c file
*******************************************************/
#include "../include.h"

IPROC initproc;  // initial PROC for P0
PRES  initpres;  // resource struct of P0
/*************************************************************
 NPROC+NTHREAD procs are constructed in the area of 3MB
*************************************************************/
PRES *pres;
PROC *proc;
PROC *freeList,*tfreeList;
PROC *running, *readyQueue, *sleepList;

int ntasks;
int ntthreads = NTHREAD;
int procsize = sizeof(PROC);
int p0stack  = (int)&initproc.kstack[SSIZE];

struct semaphore loadsem;
int sw_flag;
int boot_dev;
int HD;

struct devtab devtab[NDEV];

u64 *gdt = (u64 *)GDT_ADDR;     // GDT_ADDR at 0x80104000; 

static inline void ltr(u16 sel)
{
  asm volatile("ltr %0" : : "r" (sel));
}

int set_tss(u32 tss)
{
    u64 tss_entry = 0x0080890000000067ULL;
    u64 addr = (u64)tss;
    tss_entry |= ((addr)<<16) & 0xffffff0000ULL;
    tss_entry |= ((addr)<<32) & 0xff00000000000000ULL;
    gdt[GDT_TSS_INDEX] = tss_entry;
}

int switch_tss(PROC *p)
{
    set_tss((int)&p->tss);
    // __asm__ ("ltrw  %%ax\n\t"::"a"(GDT_TSS_SEL));
    ltr(GDT_TSS_SEL);
}    
/***********************************************************************
            build free PROC and THREAD PROC lists
************************************************************************/

PROC *build_proc_list(PROC *p, PRES *pres, int n, int startpid, int type)
{
  int i, j;
  PROC *q = p;
  for (i=0; i<n; i++){
     q->pid = startpid + i;     // assign pid = startpid + index
     q->status = FREE;
     q->next = q+1;             // link to the next PROC
     q->proc = q;               // each PORC points to itself
     q->inkmode = 1;

     q->type = type;            // PROCESS or THREAD
     q->res  = 0;
     if (type==PROCESS){        // only PROCESS has rescource 
        q->res = &pres[i];
        for (j=0; j<NFD; j++)
            pres[i].fd[j] = 0;
        pres[i].signal = 0;
        for (j=0; j<NSIG; j++)
	    pres[i].sig[j] = 0;

        q->res->tcount = 1;
        q->res->uid = q->res->gid = 0;
        q->res->name[0] = 0;
        // for message queue
        q->res->message.value=0; q->res->message.queue=0;
        q->res->mlock.value = 1; q->res->mlock.queue = 0;
        q->res->mqueue = 0;
     }
     q++;                       // next PROC struct
  }
  q--; q->next = 0;             // last PROC -> 0
  return p;       
}

int kernel_init()
{
   int i, j; 
   PROC *p; 

   printf("kernel_init() NPROC=%d NTHREAD=%d\n", NPROC,NTHREAD);
   loadsem.value = 1; loadsem.queue = 0;

   //printf("initialize PROCs\n");  
   proc = (PROC *)PROC_BASE;     // construct procs at VA=5MB
   pres = (PRES *)PRES_BASE;     // resource struts in high end of 5MB    

   freeList  = build_proc_list(&proc[0], &pres[0], NPROC, 1, PROCESS);
   tfreeList = build_proc_list(&proc[NPROC], 0, NTHREAD, NPROC+1, THREAD);

   readyQueue = 0;               // readyQueue   
   sleepList = 0;                // sleepList

   kpgdir = (u32 *)kpgtable();
   printf("switch to kgpdir and enable paging\n");
   switch_pgdir(kpgdir);

   printf("creating P0 as running\n");
   // P0 uses the statically allocated initproc[0], with pid=0
   running = p = (PROC *)&initproc;
   p->res = &initpres;
 
   p->next = 0;
   p->pri = 0;  
   p->status = READY;
   p->inkmode = 1;
   p->ppid = p->pid;

   p->res->uid = p->res->gid = 0;    
   p->res->signal = 0;
   p->res->name[0] = 0;
   p->time = 10000;              // arbitray since P0's p time never decreases

   for (i=0; i<NFD; i++)
     p->res->fd[i] = 0;
   for (i=0; i<NSIG; i++)
     p->res->sig[i] = 0;

   p->res->pgdir = kpgdir;      // P0's pgdir is kpgdir
   //printf("P0's pgdir=kpgdir at %x\n", p->res->pgdir);
  
   /* set P0's interrupt stack to its TSS */
   setzero((char *)&p->tss, sizeof(TSS));
   p->tss.esp0 = (unsigned)&p->kstack[SSIZE];
   p->tss.ss0 = KDATA;

   //printf("ssp0=%x  p0stack=%x ", &p->kstack[SSIZE], p0stack);
   /******** these are not needed since P0 never runs in Umode *********
   p->tss.es = p->tss.ds = USER_DATA;
   p->tss.ss = p->tss.gs = USER_DATA;
   p->tss.cs = USER_CODE;
   p->tss.ldt = 0x20;
   p->tss.iobitmap = 0;
   p->res->size = 0;
   ******************************************************************/
   switch_tss(p);               // set interrupt stack to P0's kstack
   ntasks = 0;
   //printf("done kernel init()\n");
   return 0;
}   

int schedule(PROC *p) // called by wakeup() and V() for new ready p
{
  if (p->status==READY)
      enqueue(&readyQueue, p);

  if (p->pri > running->pri){
     // uncomment to see task switch by priority
     // printf("%d[%d] -> %d[%d]\n",running->pid,running->pri,p->pid,p->pri);
     sw_flag = 1;
  }
}

int reschedule()
{
  if (sw_flag){
     running->pri = 128 - running->cpu;
     tswitch();
  }
}
int upriority()
{
  // drop back to Umode priority 128
  running->pri = 128-running->cpu;
}

#define SLICE 10
PROC *scheduler()
{ 
  int *cp; int i; u32 pgt_entry, up, cr0, cr3;
  // printf("proc %d in scheduler status=%d\n", running->pid, running->status);
  PROC *old;

  old = running;
  //  printf("%d in scheduler ", running->pid);

  if (running->status == READY)
      enqueue(&readyQueue,running);

  if (running->pid==0 && running->status != READY){ // if P0 is blocked
     unlock();             // MUST unlock!! else HD interrupts will NOT occur.
     while(readyQueue==0); // loop until P0 is V-ed into ReadyQueue
  }

  running = (PROC *)dequeue(&readyQueue);

  if (running->status == FORKED){
     running->status = READY;
  } 
  if (running != old){
       //printf("running=%d old=%d\n", running->pid, old->pid);
      lock();
       //printf("switch to %d's tss pgdir ", running->pid);
       switch_tss(running); 
       //cr3 = (u32)PA(running->res->pgdir);
       cr3 = PA((u32)running->res->pgdir);
       asm volatile("mov %0, %%cr3"::"r"(cr3));
      unlock();
  }
  running->time = SLICE;  // may use small time quantum, e.g.3  
  sw_flag = 0; 
 return running;
}

int main()
{
  // free page frames begin at 8MB
  printf("VERSION=");

  #ifdef QEMU
    printf("QEMU ");
  #else
    printf("VMWARE ");
  #endif
 
  printf("kpgdir at %x kpgtables at %x\n", KPG_DIR, KPG_TABLE);

  kfork("/bin/init");   // fork P1

  while(1){
     unlock();
     if (readyQueue){
        tswitch();      // tswitch() to a ready proc in readyQ
     }
     halt();
  }
}
