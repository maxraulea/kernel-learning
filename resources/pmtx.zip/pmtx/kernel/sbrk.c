/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/******************* sbrk.c *******************************/
#include "../include.h"
// sbrk.c: expand process Umode heap size by adding a page frame; return VA
/***************************************************************
 Each PROC has a p->res->pgdir containing 1024 entries
 pgdir[0] -> pgtable of 1024 entries for 4MB Umode pages
 Umode image uses the entire 4MB since ustack is at the high end of this 4MB.
 To add any additional pages, need pgdir[1]->pgtable of 1024 entries
 Since new pages are added one at a time, fill the pgtable with 1,2,.. valid
 entries at a time; the rest of 0's for un-allocated page frames.

 General: 
  should test each pgdir[i]'s pgtable entries. If a pgdir[i]'s pgtable
  is not full, allocate a pgtable entry in that pgtable.
  If all pgtables of all pdgir[i] are full:
     allocate a pgdir[i+1], allocate a pgtable for it, and allocate a pgtable
     entry in the new pgtable.
************************************************************/
int sbrk() // assume expand by one page
{
  PROC *p;
  int i, n;
  u32 up, pte, cr3;
  u32 *pgtable;
  u32 NUPAGES = running->res->size / 0x400000;
  
  p = running;
  printf("kernel sbrk():size=%x", running->res->size);
  printf("p->res->pgdir=%x\n", p->res->pgdir);

  /********* General: for readers to complete ************
  for (i=0; i<512; i++){
    if (p->res->pgdir[i]){
       printf("pdgir[%d] is non-zero\n", i);
       pgtable = pgdir[i]&0xFFFFF000;
       for (j=0; j<1024; j++){
          if (pgtable[j])
             continue;       // looking for a zero pgtable entry
       }
       if (i<1024){ //pgtable[i] is zero: allocate a frame
          pte = palloc();
          pgtable[i] = (PA(pte+7);
          return 0x400000+....
       }
    }
    // all pgtables are full, pgdir[i] is zero   
    // allocate a page frame for pgdiir[i]
    p->res->pgdir[i] = (u32 *)palloc();
    // allocate a pgtable
    pgtable = (u32 *)palloc();
    p->res->pgdir[i] = PA((u32)pgtable) + 7; // record its PA+7 in pgdir[i]
    //printf("pgtable=%x pdir[0]=%x\n", pgtable, p->res->pgdir[0]);
    for (i=0; i<1024; i++)  // zero out all entries in pgtable
         pgtable[i] = 0;
    // allocate a frame for page talbe[0]
    pte = palloc();                // get a page frame; its PA is the frame
    pgtable[0] = PA(pte+7);
    return VA should be i*4M + j*4096;
  }
  ******************************/

  /*********** handles only the ONE 4MB of pgdir[NUPAGES] ***********/
  n = NUPAGES;
  if (p->res->pgdir[n] == 0){
      printf("pdgir[%d] is zero\n", n);
      // allocate a pgtable
      pgtable = (u32 *)palloc();
 
      p->res->pgdir[n] = PA((u32)pgtable) + 7; // record its PA+7
      printf("allocated pgtable=%x pgdir[n]=%x\n", pgtable, p->res->pgdir[n]);
      for (i=0; i<1024; i++)  // zero out all entries in pgtable
           pgtable[i] = 0;
      // allocate a frame for page talbe[0]
      pte = palloc();                // get a page frame; its PA is the frame
      pgtable[0] = PA(pte+7);
      //  return Umode VA: 4M if only one extra page allocated
      cr3 = PA((u32)running->res->pgdir);
      asm volatile("mov %0, %%cr3"::"r"(cr3));
      return n*0x400000;
  }
  printf("p->res->pgdir[%d]=%x\n", n, p->res->pgdir[n]);

  // pgdir[n] already allocated: go to its pgtable to add new entry
  pgtable = (u32 *)VA(p->res->pgdir[n]&0xFFFFF000);
  printf("pgtable=%x\n", pgtable);
  // looking for 0 entry in pgtable
  for (i=0; i<1024; i++){
    if (pgtable[i]==0){
      printf("pgtable[%d] is zero\n", i);
      // allocate a new frame
      pte = palloc();
      pgtable[i] = PA(pte+7);      
      //return pgtable[i];
      printf("allocated pagetable[%d]=%x\n",i, pgtable[i]);
      cr3 = PA((u32)running->res->pgdir);
      asm volatile("mov %0, %%cr3"::"r"(cr3));
      return n*0x400000 + i*4096;
    }
  }
}
