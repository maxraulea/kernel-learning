/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
#include "../include.h"

#define PGDIRSIZE 0x400000

// help function: print number of pgdir entries and of page tables  
int prpgdir(u32 *pgdir)
{
  int i, j, npgdirs, npages;
  u32 *pgtable, a;
  
  npgdirs = npages = 0;

  for (i=0; i<512; i++){
     if (pgdir[i] == 0)
        break;
     // printf("pgdir[%d]=%x\n", i, pgdir[i]);
     npgdirs++;

     a = VA(pgdir[i] & 0xFFFFF000);
     pgtable = (u32 *)a;

     for (j=0; j<1024; j++){
       if (pgtable[j] == 0)
	   break;
       npages++;
     }
  }
  printf("npgdirs=%d npages=%d\n", npgdirs, npages);
}

/************************ kexec():*************************************
   Get filename and size from Umode; size parameter=0 if new no new size
   Allocate new image of original size OR new size if specified.
   Load filename to new image
   Release old image if NOT vforked.
   Reset kstack frame to return to Umode at UCS:0
                These can be refined to:
   Allocate new image only if NOT vforked AND specifed new size
   if (new image): load file to new image;
   else            load file to original image
   Release old image only if NOT vforked AND has new image
********************************************************************/
int kexec(char *y, int size)
{
  char string[508], filename[64], tname[64], pgname[64];
  char *cp, *cq;
  int i, n, r, newsize, vforked, nframe;
  u32 *pgtable, cr3;
  u32  TOP;
  u32 *new_pgdir, new_size, *saved_pgdir, saved_size;
  u32 *addr;
  char type;
  PROC *p = running;
  
  newsize = 0; 
  vforked = 0;
  if (running->vforked)
     vforked = 1;

  color = RED;
  //printf("%d : exec %s, size=%d\n", running->pid, y, size);
  if (p->type != PROCESS){
    printf("EXEC: %d is a thread, can't exec\n", p->pid);
    return -1;
  }
  if (p->res->tcount > 1){
    printf("EXEC: %d tcount>1,can't exec\n", p->pid);
    return -1;
  }

  strcpy(string, y);
  
  /* get first token of string as filename */
  cp = string; cq = filename;
  while(*cp && *cp != ' '){
    *cq++ = *cp++;
  }
  *cq = 0;

  strcpy(pgname, filename);

  // fix up filename
  if (filename[0] != '/'){
    strcpy(tname, "/bin/");
    strcat(tname, filename);
    strcpy(filename, tname);
  }

  newsize = size;
  saved_pgdir = running->res->pgdir; // save original pgdir
  saved_size  = running->res->size;  // save original size

  new_size = saved_size;
  // if newsize: set new SIZE, else same as original size
  if (size){
     new_size = running->res->size = size*0x100000;  // n MB new size
     nframe = nframes();
     if (nframe*4096 < new_size){
         printf("kexec: OUT OF MEMORY newsize=%d nframes=%d\n",
                        new_size/4096, nframe);
         return -1;
     }
  }

  // allocate new image for ALL cases: vforked or newsize 
  new_pgdir = (u32 *)palloc();
  if (new_pgdir == 0){
     return -1;       
  }
  if (size)
    printf("proc %d: allocate new image pgdir=%x SIZE=%x\n", 
           running->pid, new_pgdir, new_size);      

  running->res->new_pgdir = new_pgdir;
  running->res->new_size  = new_size;
  
  r = makePage(running, EXEC);  // from kexec()

  if (r == 0){  // out of memory
     printf("kexec: out of memory: release new image\n");
     prpgdir(new_pgdir);
     freeImage(new_pgdir);
     pdealloc(new_pgdir);
     return -1;
  }

  // switch to new_pgdir
  running->res->pgdir = new_pgdir;
  running->res->size  = new_size;
  
  //switch_pgdir(PA(running->res->pgdir));
  cr3 = PA((u32)running->res->pgdir);
  asm volatile("mov %0, %%cr3"::"r"(cr3)); 

  if (load(filename, running) < 0){ // if loading file fails
     // if caller is vforked: MUST die
     /********* Option 1:. call kexit() directly ***************
     if (vforked){
         printf("vforked proc %d: kexit(2)\n", running->pid);
         running->vforked = 0; // do NOT release SHARED image in kexit()
         kexit(2);
     }
     ********************************************************/
     /******** Option 2: return to new image to do exit(2)  **********
     if (vforked){
        printf("proc %d: return to do exit(2) in new image\n",running->pid);
        // copy syscall(9,2) to to new image and let it return to new image.
        pgtable = (u32 *)VA(running->res->pgdir[0]&0xFFFFF000);
        addr    = (u32 *)VA(pgtable[0]&0xFFFFF000);
        // code in HEX = 0x 6A01 6A09 6a00 CD80
        *addr     = 0x096A026A;  // pushl $2; pushl $9
        *(addr+1) = 0x80CD006A;  // pushl $0; INT $0x80
	//printf("addr=%x, contents=%x %x\n", addr,addr+1,*addr,*(addr+1));  
      goto out;
     }
     //*****************************************************************/

     printf("proc %d: restore OLD image pgdir=%x\n", p->pid, saved_pgdir);
     running->res->pgdir = saved_pgdir; // restore original image
     running->res->size  = saved_size;  // and size

     cr3 = PA((u32)saved_pgdir);// switch back to origianl image
     asm volatile("mov %0, %%cr3"::"r"(cr3));

     printf("proc %d: release NEW IMAGE pgdir=%x size=%x\n",  
            running->pid, new_pgdir, new_size);
     //prpgdir(new_pgdir);

     freeImage(new_pgdir);    // release new image but keep new_pgdir
     pdealloc(new_pgdir);     // deallocate new_pgdir last
     return -1;
  }

  // load file OK: if has new image AND caller is NOT vforked: release old image
  if (newsize && !vforked){
      printf("proc %d: release  OLD IMAGE pgdir=%x size=%x\n",
	     running->pid, saved_pgdir, saved_size);
      //prpgdir(saved_pgdir);
  }
  if (!vforked){
     freeImage(saved_pgdir);
     pdealloc(saved_pgdir);
  }

  strcpy(running->res->name, pgname);

 out:
  TOP = running->res->size;
  /* copy string to ustack high end */
  cp = (char *)(TOP - 508);
  strcpy(cp, string);
  *(int *)(TOP - 512) = TOP-508;

  /*********  kstack of new proc contains: *********************
  |uss|usp|flag|ucs|upc|ax|bx|cx|dx|bp|si|di|uds|ues|ufs|ugs|
    1   2   3    4   5  6  7  8  9  10 11 12 13  14  15  16
  |goU|PC|ax|bx|cx|dx|bp|si|di|flag|
    17 18 19 20 21 22 23 24 25  26
  
  in ustack top: ptr->string of up to 512-4 chars
  copy string to TOP - 508
  *************************************************************/
  
  /* clear "saved registers" to 0 */ 
  for (i=1; i<27; i++)
       running->kstack[SSIZE-i] = 0;

  /* fill in the needed entries */
  running->kstack[SSIZE-1] = UDS;
  running->kstack[SSIZE-2] = TOP-512;     /* 128*4096 relative to base */
  running->kstack[SSIZE-3] = UFLAG;
  running->kstack[SSIZE-4] = UCS;
  running->kstack[SSIZE-5] = 0x0;          /* virtual address 0 in UCS */

  running->kstack[SSIZE-13] = running->kstack[SSIZE-14] = 
  running->kstack[SSIZE-15] = running->kstack[SSIZE-16] = UDS;

  running->kstack[SSIZE-17] = (int)goUmode;
  running->ksp = (int *)&(running->kstack[SSIZE-25]);

  //  reset signals 
  for (i=0; i<NSIG; i++)
    running->res->sig[i] = 0;
  running->res->signal = 0;

  if (vforked)
     running->vforked = 0; // if vforked, turn off vforked flag

  return 0;
}

