/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
#include "../include.h"

static const char *exception_msg[ ] = {
       "DIVIDE ERROR","DEBUG EXCEPTION","BREAKPOINT","NMI","OVERFLOW",
       "BOUNDS CHECK","INVALID OPCODE","COPROCESSOR NOT VALID","DOUBLE FAULT",
       "OVERRUN","INVALID TSS","SEGMENTATION NOT PRESENT","STACK EXCEPTION",
       "GENERAL PROTECTION","PAGE FAULT","RESERVED","FLOATING_POINT ERROR"
};

/********************* exception kstack layout ***************************
 |oss|osp|eflag|cs|eip|0/err#|nr|ax|cx|dx|bx|esp|bp|si|di|ds|es|fs|gs|ss|
 |<----- by exception ------>|  |<----- by pushal ------>|
**************************************************************************/

int ehandler(u32 signal, u32 ret_ip, u32 ss, u32 gs, u32 fs, u32 es, u32 ds, 
u32 edi, u32 esi, u32 ebp, u32 esp, u32 ebx, u32 edx, u32 ecx, u32 eax, 
u32 trap_nr, u32 err, u32 eip, u32 cs, u32 eflags, u32 old_esp, u32 old_ss)
{
  u32 cr2, cr3;  int pgentry; u32 *pgtable;
    color = 0x0B;
    printf("%d inkmode=%d\n", running->pid, running->inkmode);
    if (running->inkmode == 1){ // trap was is Umode: send signal to PROC
	if (trap_nr < sizeof exception_msg)
           printf("EXCEPTION %d: %s\n=======================\n",
	                    trap_nr, exception_msg[trap_nr]);
	else
	   printf("INTERRUPT %d\n=======================\n", trap_nr);

         __asm__ __volatile__ ("movl %%cr2, %%eax":"=a"(cr2));
         __asm__ __volatile__ ("movl %%cr3, %%eax":"=a"(cr3));

	printf("cs:\t%x\teip:\t%x\teflags:\t%x\n", cs, eip, eflags);
	printf("ss:\t%x\tesp:\t%x\n", ss, esp);
	printf("old ss:\t%x\told esp:%x\n", old_ss, old_esp);
	printf("errcode:%x\tcr2:\t%x\tcr3:\t%x\n", err, cr2, cr3);

        if (trap_nr==14){
	  printf("page fault handler: cr2 address=%x\n", cr2);
          pgentry = cr2/4096;
          printf("pgentry=%d ", pgentry);
          if (pgentry < 1024){  // if within the 4MB VA
	    /*************************
            pgtable = PA((u32 *)running->res->pgdir[0]&0xFFFFF000);
            printf("pgtable=%x pgEntry=%x ", pgtable, pgtable[pgentry]);

            pgtable[pgentry] |= 0x1;  // mark missing page as Present
            printf("pgEntry=%x\n",pgtable[pgentry]);
	    **************************/
            page_in(pgentry);
            cr3 = PA((u32)running->res->pgdir);
            asm volatile("mov %0, %%cr3"::"r"(cr3));
            printf("marked page %d PRESENT, proc continues\n", pgentry);
            return;
	  }
	}
	//  uncomment these to show CPU registers at trap point
        /*
	printf("General Registers:\n=======================\n");
	printf("eax:\t%x\tebx:\t%x\n", eax, ebx);
	printf("ecx:\t%x\tedx:\t%x\n", ecx, edx);
	printf("esi:\t%x\tedi:\t%x\tebp:\t%x\n", esi, edi, ebp);
	printf("Segment Registers:\n=======================\n");
	printf("ds:\t%x\tes:\t%x\n", ds, es);
	printf("fs:\t%x\tgs:\t%x\n", fs, gs);
	*/
        printf("proc %d trap %d in Umode signal=%x\n", 
                running->pid, trap_nr, signal); 
        setsig(signal);
    }
    else{
        printf("kernel PANIC trap=%x signal#=%d\n", trap_nr, signal);
        __asm__ __volatile__ ("movl %%cr2, %%eax":"=a"(cr2));
        __asm__ __volatile__ ("movl %%cr3, %%eax":"=a"(cr3));

	if (trap_nr < sizeof exception_msg)
           printf("EXCEPTION %d: %s\n=======================\n",
	                    trap_nr, exception_msg[trap_nr]);
	else
	   printf("INTERRUPT %d\n=======================\n", trap_nr);

	printf("cs:\t%x\teip:\t%x\teflags:\t%x\n", cs, eip, eflags);
	printf("ss:\t%x\tesp:\t%x\n", ss, esp);
	printf("old ss:\t%x\told esp:%x\n", old_ss, old_esp);
	printf("errcode:%x\tcr2:\t%x\tcr3:\t%x\n", err, cr2, cr3);
	printf("General Registers:\n=======================\n");
	printf("eax:\t%x\tebx:\t%x\n", eax, ebx);
	printf("ecx:\t%x\tedx:\t%x\n", ecx, edx);
	printf("esi:\t%x\tedi:\t%x\tebp:\t%x\n", esi, edi, ebp);
	printf("Segment Registers:\n=======================\n");
	printf("ds:\t%x\tes:\t%x\n", ds, es);
	printf("fs:\t%x\tgs:\t%x\n", fs, gs);

        halt();
    }
    color = 0x0C;
    return;
}

/*************** tell compiler these are entryPoints **************/
extern int trap0x00(),trap0x01(),trap0x02(),trap0x03(),trap0x04(),
trap0x05(),trap0x06(),trap0x07(),trap0x08(),trap0x09(),trap0x0A(),
trap0x0B(),trap0x0C(),trap0x0D(),trap0x0E(),trap0x0F(),trap0x10(),
trap0x11(),trap0x12(),trap0x13(),trap0x14(),trap0x15(),trap0x16(),
trap0x17(),trap0x18(),trap0x19(),trap0x1A(),trap0x1B(),trap0x1C(),
trap0x1D(),trap0x1E(),trap0x1F(); 

int (*intEntry[ ])() = 
{/********************** 32 trap/fault entryPoints **********************/
 trap0x00, trap0x01, trap0x02, trap0x03, trap0x04, trap0x05, trap0x06, trap0x07,
 trap0x08, trap0x09, trap0x0A, trap0x0B, trap0x0C, trap0x0D, trap0x0E, trap0x0F,
 trap0x10, trap0x11, trap0x12, trap0x13, trap0x14, trap0x15, trap0x16, trap0x17,
 trap0x18, trap0x19, trap0x1A, trap0x1B, trap0x1C, trap0x1D, trap0x1E, trap0x1F
 /* 16 IRQs are remapped to 0x20-0x2F; entryPoints installed in init.c */
};

/************** tell compiler these are handler functions ***************/
extern int 
  divide_error(),    debug_exception(),     nmi(),            breakpoint(),
  overflow(),        bounds_check(),        invalid_opcode(), cop_not_avalid(),
  double_fault(),    overrun(),             invalid_tss(),    seg_not_present(),
  stack_exception(), general_protection(),  page_fault(),     reserved(),
  floating_point(),  reserved(),            thandler(),        kbhandler();

int (*intHandler[ ])()= /**** trap/interrupt handler functions ***/
{
  divide_error,    debug_exception,     nmi,            breakpoint,
  overflow,        bounds_check,        invalid_opcode, cop_not_avalid,
  double_fault,    overrun,             invalid_tss,    seg_not_present,
  stack_exception, general_protection, 	page_fault,     reserved,
  floating_point,  reserved,     	reserved,       reserved,
  reserved,        reserved,            reserved,       reserved, 
  reserved,        reserved,            reserved,       reserved, 
  reserved,        reserved,            reserved,       reserved 
};

u64 *idt = (u64 *)IDT_ADDR;  // 0x80105000 defined in include.h

struct idt_des{
       u16 length;
       u32 address;
}__attribute__ ((packed)) idt_descr = {256*8-1, IDT_ADDR};

int trap_entry(int index, u32 offset)
{
  u64 idt_entry = (u64)((u64)0x00008e0000000000ULL | (u64)(KCODE<<16));
  u64 addr = (u64)offset;

  idt_entry |= (addr<<32) & (u64)0xffff000000000000ULL;
  idt_entry |= (addr) & 0xffff;
  idt[index] = idt_entry;
}

/* use intEntry[ ]={trap0x00,trap0x01,... }as entry address *******/ 
int trap_install()
{
     int i;
     //printf("idt_install ");
     for (i=0; i<32; ++i)         // first 32 trap vectors 
       trap_entry(i, (unsigned int)(intEntry[i]));
     //printf("done 32 ");

     for (++i; i<256; ++i)        // rest vectors 
	trap_entry(i, (unsigned int)default_trap);
     //printf("done all ");

     lock();
     __asm__ ("lidt	%0\n\t"::"m"(idt_descr));  // IDTR

     return;
}

/***** remap IRQ0-15 vectors to 0x20-0x2F ********/
int remap_IRQ( ) 
{
  out_byte(0x20, 0x11);
  out_byte(0xA0, 0x11);
  out_byte(0x21, 0x20);
  out_byte(0xA1, 0x28);
  out_byte(0x21, 0x04);
  out_byte(0xA1, 0x02);
  out_byte(0x21, 0x01);
  out_byte(0xA1, 0x01);
  
  /* leave all IRQ enabled */ 
  out_byte(0x21,0x80);
}

int int_install(int vector, int int_entry)
{
  u64 int_desc = (u64)((u64)0x0000ef0000080000ULL | (u64)(KCODE<<16));
  int_desc |= ((u64)int_entry<<32) & (u64)0xffff000000000000ULL;
  int_desc |= ((u64)int_entry) & 0xffff;
  idt[vector] = int_desc;
}

void dtrap()  // any unexpected trap
{
  printf("proc %d : unknown trap\n", running->pid);
  if (running->inkmode == 1){
     setsig(0x05l);
     return;
  }
  printf("kernel PANIC! unknown trap in Kmode\n");
  halt();
}


int page_in(int n) // mark PROC's nth pagetable entry as NOT present
{
  u32 *pgtable;
  pgtable = (u32 *)PA((u32)(running->res->pgdir[0]&0xFFFFF000));
  printf("pgtable=%x pgEntry=%x ", pgtable, pgtable[n]);
  pgtable[n] |= 0x1;  // mark missing page as Present
  printf("changed pgEntry=%x\n",pgtable[n]);
  return 0;
}

int page_out(int n) // mark PROC's nth pagetable entry as NOT present
{
  u32 *pgtable;

  pgtable = (u32 *)PA((u32)running->res->pgdir[0]&0xFFFFF000);
  printf("pgtable=%x pgEntry=%x ", pgtable, pgtable[n]);
  pgtable[n] &= 0xFFFFFFFE;  // mark nth page as NOT present
  printf("changed pgEntry=%x ", pgtable[n]);
  return 0;
}

