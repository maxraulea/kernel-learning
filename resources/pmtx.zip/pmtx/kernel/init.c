/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
#include "../include.h"

//#define NSEGS        6
/******* in include.h *********
#define GDT_ADDR    0x80104000
#define GDT_ENTRIES 6
#define GDT_SIZE   (8*GDT_ENTRIES)
#define IDT_ADDR    0x80105000
#define IDT_SIZE       (256*8)
#define KPG_DIR     0x80106000
#define KPG_TABLE   0x80400000
#define PROC_BASE   0x80500000
#define PRES_BASE   0x805E0000
#define BUFFER_BASE 0x80700000
*****************************/
#define NPGTABLE            128
#define PGSIZE             4096

u32 *kpgdir;
u32 *pfreeList;

static inline void lcr3(u32 val)
{
  asm volatile("movl %0, %%cr3" : : "r"(val));
}

void switch_pgdir(u32 *pgdir)
{
  lcr3(PA((u32)pgdir));       // switch to the kernel page table
}

int nframes() // return the number of entries in pfreeList
{
  int n = 0;
  u32 *p = pfreeList;
  while(p){
    p = (u32 *)*p;
    n++;
  }
  return n;
}
int pnframes() // return the number of entries in pfreeList
{
  int n = 0;
 int *p = pfreeList;
  while(p){
    p = (u32 *)*p;
    n++;
  }
  printf("nframes = %d\n", n);
}

u32 *palloc()
{
  u32 *p = pfreeList;

  if (pfreeList==0)
     return 0;

  pfreeList = (u32 *)*p;
  return p;
}

void pdealloc(u32 *p)         // p is the VA of a page frame
{
  u32 *a;
  a = (u32 *)((u32)p & 0xFFFFF000); 
  *a = (u32)pfreeList;
  pfreeList = a;
}

u32 *free_page_list(u32 startva, u32 endva)
{
  int i = 0; 
  u32 *p;
  printf("build pfreeList: start=%x end=%x\n", startva, endva);
  p = (u32 *)startva;

  while(p < (u32 *)(endva-4096)){
    *p = (u32)(p + 1024);
     p += 1024;
  }
  *p = 0;
  /********* debugging print ********
  printf("\n------------\n");
  for (i=0; i<4; i++){
    printf("[%x %x] ", p, *p);
    p = (u32 *)(*p);
  }
  **********************************/
   return (u32 *)startva;
}

/*********************************************************************
 When MTX starts, VA 0-8M is identity mapped tp physical memory 0-8M
 Assume: MTX kernel occupies 1M-4M for a total of 3MB ==> 4MB and above is free.
 We shall build the kernel's kpgdir at 4MB and its pgtables at 4MB+4KB,
 and the PROCs and PRES structures in 5MB
 Assume: 512 MB physical memory => 512/4=128 page tables
1. KPGDIR is at VA=0x80400000 or 4MB
    entries 0-511 are zero's since P0 never runs in Umode
    entries 512-640 point to 128 page tables at 4M+4KB,4M+8K,.(at most) to 5MB
2. Every other proc's pgdir is allocated dynamically from pfreeList.
    copy KPGDIR to proc's kpgdir ==> entries 512-640 are same as KPGDIR
    each proc's is allocated a pgdir[0], with 1024 pgtables for Umode 4MB space
*******************************************************************/  
u32 *kpgtable(void)
{
  int i, j;
  u32 pte;
  u32 *pgdir, *pgtable;

  pgdir = (u32 *)KPG_DIR;                // kpgdir at VA=0x80106000
  for (i=0; i<1024; i++)
      pgdir[i] = 0;                      // zero out pgdir

  pte = (u32)(PA(KPG_TABLE)+3);          // kpgtables begin at 4MB+4KB,0x3=K,P

  for (i=512; i<NPGTABLE+512; i++){      // fill entries 512 to 512+128 
      pgdir[i] = pte;                    // pointing at pgtables.
      pte += 4096;
  }
  pte = 0x3;                             // fill 128 pgtables, which map
  pgtable = (u32 *)KPG_TABLE;            // [0x80000000 - 0x80000000+512MB]
  for (i=0; i<NPGTABLE; i++){            // to [0-512MB]  
      for (j=0; j<1024; j++){ 
          pgtable[i*1024 + j] = pte;
          pte += 4096;
      }
  }
  return (u32*)KPG_DIR;
}
/******** debugging print *********
void pkdir()
{
  int i;
  for (i=0; i<512+NPGTABLE; i++){
    if (kpgdir[i])
       printf("[%d %x] ", i, kpgdir[i]);
  }
}
********************************/

int init(u32 korg, u32 ksp)
{
  int i,j,k; int *bdev;
  u32 *ka, *pa;
  u32 kaddress = *(u32 *)0x90010;

  vid_init();
  color = 0x0C;

  printf("Welcome to PMTX in 32-bit Protected Mode using Dynamic Paging\n");
  printf("MTX kernel running at %x ksp=%x\n", kaddress, ksp);
  printf("kpgdir at %x ", KPG_DIR);
  /**********
  kpgdir = kpgtable();
  printf("switch to kgpdir and enable paging\n");
  switch_pgdir(kpgdir);
  *********/
  kernel_init();  
  printf("remap IRQs; install IDT vectors and handlers\n"); 
  remap_IRQ(); 
  trap_install(); 
     /******** IRQ 0-15 are remapped to 0x20-0x2F ********/
     int_install(0x20, (int)tinth);   // timer IRQ was   0
     int_install(0x21, (int)kbinth);  // KBD   IRQ was   1

     int_install(0x23, (int)s1inth);  // serial port 1   3
     int_install(0x24, (int)s0inth);  // serial port 0   4
     int_install(0x26, (int)fdinth);  // FD IRQ was      6  
     int_install(0x27, (int)printh);  // printer IRQ was 7
       
     int_install(0x2E, (int)hdinth);  // IDE0 was IRQ   14
     int_install(0x2F, (int)cdinth);  // IDE1 was IRQ   15
     
     int_install(0x80, (int)int80h);  // syscall  =   0x80
     printf("initialize I/O buffers and device drivers\n");

  pipe_init();
  binit(1);
  fd_init();
  hd_init();
  kb_init();
  serial_init();
  pr_init();
  cd_init();

  mbuf_init();
  timer_init();

  bdev = (int *)(0x80000000+0x90000+508);
  boot_dev = (*bdev) & 0x000000FF;

  //printf("init: boot_dev = %d\n", boot_dev);
  HD = boot_dev;

  fs_init();
  running->res->cwd = root;

  // free page frames begin at 8MB
  pfreeList = free_page_list(0x80800000, 0xA0000000);
  //pnframes();

  main();
}

