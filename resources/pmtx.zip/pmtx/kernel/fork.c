/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
#include "../include.h"

#define PGSIZE   4096

PROC *fork1(int HOW)  // HOW=FORK: allocate pgdir else do not allocate pgdir
{
  PROC *p; int i; u32 up, pte;
  u32 *pgtable;

  /*** get a proc for child task: ***/
  if ( (p = (PROC *)get_proc(&freeList)) == NULL){
       printf("\nno more PROC  ");
       return 0;
  }
  // allocate kstack
  p->kstack = (u32 *)palloc();
  if (p->kstack == 0){
     put_proc(&freeList, p);
     return 0;
  }
  // allocate pgdir
  if (HOW==FORK){
    p->res->pgdir = (u32 *)palloc();  // alocate a pgdir
     if (p->res->pgdir == 0){
        put_proc(&freeList, p);
        return 0;
     }
  }
  else{  // called from vfrok()
    p->res->pgdir = running->res->pgdir;
  }

  /* initialize the new PROC and its kstack */
  p->status = READY;
  p->ppid = running->pid;
  p->parent = running;
  p->pri  = 128;
  p->inkmode = 1;
  p->time = 0;
  p->cpu = 0;
  p->type = PROCESS;

  p->res->size = running->res->size;

  p->res->uid = running->res->uid;
  p->res->gid = running->res->gid;
  p->res->cwd = running->res->cwd;
  p->res->tcount = 1;
  p->res->cwd->refCount++;

  // p->res->signal, p->res->sig[] are cleared in kexit()
  p->res->signal = 0;
  for (i=0; i<NSIG; i++)
    p->res->sig[i] = 0;

  /**** copy file descriptors ****/
  for (i=0; i<NFD; i++){
      p->res->fd[i] = running->res->fd[i];
      if (p->res->fd[i] != 0)
          p->res->fd[i]->refCount++;
  }
  /***** clear message queue ******/
  p->res->mqueue = 0; 
  p->res->mlock.value = 1; p->res->mlock.queue = 0;
  p->res->message.value = 0; p->res->message.queue = 0;

  setzero((char *)&p->tss, sizeof(TSS));
  p->tss.esp0 = (unsigned)&p->kstack[SSIZE];
  p->tss.ss0 = KDATA;
  p->tss.es  = USER_DATA;
  p->tss.ss  = USER_DATA;
  p->tss.cs  = USER_CODE;
  /* these are never used, so set to default values */
  p->tss.ldt = 0x20; 
  p->tss.iobitmap = 0;
  return p;
}

int mycpy(u32 *dest, u32 *src, u32 nlong)
{
  u32 i;
  for (i=0; i<nlong; i++){
     *dest++ = *src++;
  }
}

// copy parent's page frames to child' page frames
void copyimage(PROC *parent, PROC *p)
{
  u32 i, j;
  u32 *ppgtable, *cpgtable, *cpa, *ppa;
  u32 npgdirs = (parent->res->size + 0x400000 - 1) / 0x400000;
  //printf("size = %x  npgdirs = %d\n", parent->res->size, npgdirs);
  for (i=0; i < npgdirs; i++){ // each image has npgdir page tables
      ppgtable = (u32 *)VA(running->res->pgdir[i]&0xFFFFF000);
      cpgtable = (u32 *)VA(p->res->pgdir[i]&0xFFFFF000);

      for (j=0; j<1024; j++){
          ppa = (u32 *)VA(ppgtable[j]&0xFFFFF000);
          cpa = (u32 *)VA(cpgtable[j]&0xFFFFF000);
          mycpy(cpa, ppa, 1024);
      }
  }
}

#define PGDIRSIZE 0x400000

//****** Assume image size is a multiple of 1MB *********

int makePage(PROC *p, int HOW) // HOW=FORK for child or EXEC for new image
{
  u32 i, j, npgdirs, nframes;
  u32 size, up, pte;
  u32 *pgdir, *pgtable;
  u32 npages, rpages;
  u32 npgdir, rpgdir;

  if (HOW==FORK){
     pgdir = p->res->pgdir;
     size  = p->res->size;
  }
  if (HOW==EXEC){
     pgdir = p->res->new_pgdir;
     size  = p->res->new_size;
  }
 
  npgdirs = nframes = 0;
  npgdir = size / PGDIRSIZE;
  npages = size / PGSIZE;    // number of pages needed
  rpages = npages % 1024;    // number of remaining pages in last pgtable
  //printf("npgdir=%d npages=%d rpages=%d\n", npgdir, npages, rpages);
 
  // copy kpgdir into p->pdir (for the SAME last 512 Kmode pgdir entries)
  for (i=0; i<1024; i++)
      pgdir[i] = kpgdir[i];
 
  // allocate npgdir pgtables
  for (i=0; i<npgdir; i++){
      pgtable = (u32 *)palloc();
      if (pgtable == 0)
         return 0;
      npgdirs++;
      pgdir[i] = PA((u32)pgtable) + 7; // record its PA+7 in pgdir[0]

      // MUST zero-out pgtable, otherwise when out of memory it may contain 
      // non-zero entries that are NOT allocated => causing deallocation error
      for (j=0; j<1024; j++)  
 	  pgtable[j] = 0; 
      for (j=0; j<1024; j++){
          pte = palloc();       // get a page frame; its PA is the frame
          if (pte == 0)                // if out of memory
	    return 0;   
          pgtable[j] = PA(pte+7);
          nframes++;
      }
  }
  if (rpages){ // need one more pgdir OR pgdir[0] if size < 4M
     pgtable = (u32 *)palloc();
     if (pgtable == 0)
       return 0;

     pgdir[i] = PA((u32)pgtable) + 7;   // record its PA+7 in pgdir[0]
     //printf("pdir[%d]=%x\n", i, p->res->pgdir[i]);
     npgdirs++;

     // create a pgtable to map needed rpages
     for (j=0; j<1024; j++)            // zero out the page table first
          pgtable[j] = 0; 
     //printf("allocate %d rpage frames for pgdir[%d]\n", rpages, i);
     for (j=0; j<rpages; j++){
         pte = palloc();    // get a page frame; its PA is the frame
         if (pte == 0)
	   return 0;
         pgtable[j] = PA(pte+7);
         nframes++;
     }
  }
  //printf("makePage: npgdirs=%d, nframes=%d\n", npgdirs, nframes);
  return nframes;
}

int fork()
{
  PROC *p;  int i, j, r;
  u32  *cp, *cq, up, pte;
  u32  *pgdir;

  p = (PROC *)fork1(FORK);
  if (p==0){
     prints("fork failed\n");
     return -1;
  }
  p->vforked = 0;             // child is NOT vforked
  pgdir = p->res->pgdir;      // allocated in fork1()

  r = makePage(p, FORK);      // try to allocate pgtables

  if (r==0){ // out of memory: deallocate any pgtables in pgdir
     freeImage(pgdir);
     pdealloc(pgdir);         // deallocate pgdir itself
     put_proc(&freeList, p);  // free PROC p
     return -1;        
  }
  
  // copy parent's Umode image and kstack to child
  copyimage(running, p);
  mycpy(p->kstack, running->kstack, SSIZE);

  /* fix up child's kstack for return to its own Umode image */
  /*********  kstack of new proc contains: *********************
  |uss|usp|flag|ucs|upc|ax|bx|cx|dx|bp|si|di|uds|ues|ufs|ugs|
    1   2   3    4   5  6  7  8  9  10 11 12 13  14  15  16
  |PC|ax|bx|cx|dx|bp|si|di|flag|
   17 18 19 20 21 22 23 24  25  
  *************************************************************/
  strcpy(p->res->tty, running->res->tty); // same tty as parent
  p->kstack[SSIZE-6] = 0;              // return value=saved AX = 0
  
  for (i=17; i<26; i++)
      p->kstack[SSIZE-i] = 0;
  p->kstack[SSIZE-17] = (int)goUmode;
  p->ksp = (int *)&p->kstack[SSIZE-25];

  enqueue(&readyQueue, p);
  ntasks++;
  //printf("Task %d forked a child %d\n",running->pid, p->pid);
  return p->pid;
}

// kfork() used only by P0 to create P1 with /bin/init as its Umode image
int kfork(char *filename)
{
  PROC *p;  
  int   i;  
  char *cp;
  u32  *pgdir;

  p = (PROC *)fork1(FORK);
  if (p==0){
     prints("kfork failed\n");
     return -1;
  }
  p->vforked = 0;
  p->res->size = INITSIZE; // INITSIZE = 4MB in type.h

  // for kfork(), these must be OK, so no need to check out of memory
  makePage(p, FORK);

  strcpy(p->res->name, "init");

  /*********  kstack of new proc contains: *********************
  |uss|usp|flag|ucs|upc|ax|bx|cx|dx|bp|si|di|uds|ues|ufs|ugs|
    1   2   3    4   5  6  7  8  9  10 11 12 13  14  15  16
  |PC|ax|bx|cx|dx|bp|si|di|flag|
   17 18 19 20 21 22 23 24  25  
  *************************************************************/
  /* clear "saved registers" to 0 */ 
  for (i=1; i<26; i++)
       p->kstack[SSIZE-i] = 0;

  /* fill in the needed entries */
  p->kstack[SSIZE-1] = UDS;           // uSS
  p->kstack[SSIZE-2] = INITSIZE-4;    // uSP: 8MB image
  p->kstack[SSIZE-3] = UFLAG;         // uflag
  p->kstack[SSIZE-4] = UCS;           // UCS
  p->kstack[SSIZE-5] = 0x0000;        // ip = 0

  p->kstack[SSIZE-13] = p->kstack[SSIZE-14] = p->kstack[SSIZE-15] =
  p->kstack[SSIZE-16] = UDS;

  p->kstack[SSIZE-17] = (int)goUmode;
  p->kstack[SSIZE-25] = 0x00000200;
  p->ksp = (int *)&(p->kstack[SSIZE-25]); 

  load(filename, p);

  enqueue(&readyQueue, p);
  ntasks++;
  printf("proc %d kforked %d as init proc \n", running->pid, p->pid);
  return(p->pid);
}

int vfork()
{
  PROC *p;  
  int i, j;
  u32 *cp, *cq, up, pte; u32 cr3;
  u32 *cusp, *usp, *ccusp, *uusp;

  p = (PROC *)fork1(VFORK);              // share pgdir with parent
  if (p==0){
    prints("vfork failed\n");
    return -1;
  }
  p->vforked = 1;                        // child is vforked 

  mycpy(p->kstack, running->kstack, SSIZE);

  // must give the vfroked child a separate ustack area
  uusp = usp = (u32 *)p->kstack[SSIZE-2];
  ccusp = cusp = usp - 1024;

  while((u32)uusp < running->res->size)  // copy ustack to 4KB below
       *ccusp++ = *uusp++;

  p->kstack[SSIZE-2] = (int)cusp; // change child's usp
  printf("vfork() in kernel: parent usp=%x child usp=%x\n", usp, cusp);

  /* fix child's kstack for return to its own Umode image */
  /*********  kstack of new proc contains: *********************
  |uss|usp|flag|ucs|upc|ax|bx|cx|dx|bp|si|di|uds|ues|ufs|ugs|
    1   2   3    4   5  6  7  8  9  10 11 12 13  14  15  16
  |PC|ax|bx|cx|dx|bp|si|di|flag|
   17 18 19 20 21 22 23 24  25  
  *************************************************************/
  strcpy(p->res->tty, running->res->tty);
  p->kstack[SSIZE-6] = 0;              // return value=saved AX = 0
  
  for (i=17; i<26; i++)
      p->kstack[SSIZE-i] = 0;
  p->kstack[SSIZE-17] = (int)goUmode;
  p->kstack[SSIZE-25] = 0x0202;
  p->ksp = (int *)&p->kstack[SSIZE-25];

  p->pri = 256; // run child first, if with priority scheduling
  enqueue(&readyQueue, p);
  ntasks++;
  printf("proc %d vforked a child %d\n",running->pid, p->pid);
  return p->pid;
}

// print pgdir and pgtables of running process
int ptable()
{
  u32 *pgdir, *pgtable;
  int i, j;

  pgdir = running->res->pgdir;

  for (i=0; i<512; i++){
    if (pgdir[i] == 0)
      break;
    printf("------- pgdir contents ---------\n");
    printf("pgdir[%d] = %x\n", i, pgdir[i]);

    printf("------- pgtables contents ---------\n");

    pgtable = (u32 *)VA(running->res->pgdir[i]&0xFFFFF000);
    printf("pgtable = %x : " , pgtable);
    for (j=0; j<2; j++){
      printf("pgtable[%d] = %x ", j, pgtable[j]);
    }
    printf("\n");
  }
}

 
