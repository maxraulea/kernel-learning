/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
#include "../include.h"

/************ syscall functions *************/
int getpid()
{
  return running->pid;
}
       
int getppid()
{
  return running->ppid;
}

int getpri()
{
  return running->pri;
}

int ksetpri(int pri)
{
  running->pri = pri;
  return 0;
}

int getuid()
{
  return running->res->uid;
}

int kchuid(int uid, int gid)   // syscall chudi entry
{
    running->res->uid = uid;   // change gid,uid
    running->res->gid = gid;
    return 0;
}
int kgetPaddress()
{
  return 0;
}
/*
void goUmode();
*/
int get_uword(char *b)
{ 
    return *(int *)b;
}

int put_uword(int w, char *b)
{    
  *(int *)b = w;
}


int kpause(int y)
{
  running->pause = y;  /* pause y seconds */
  ksleep(PAUSE);
  return 0;
}

/***************************************************************
  kfork(segment) creates a child task and returns the child pid.
  When scheduled to run, the child task resumes to bodypid) in 
  K mode. Its U mode environment is set to segment.
****************************************************************/
void do_kfork()
{  
   int child;
   /* trivial memory allocate ==> proc[i] uses 0x2000+i*0x1000 */
   child = kfork();
   if (child < 0){
       printf("kfork failed\n"); 
       return;
   } 
   printf("Task %d return from kfork() : child = %d\n",
           running->pid, child);
} 


int kswitch()
{
  tswitch();
}

char buf[64];

char *hh[ ] = {"FREE   ", "READY  ", "SLEEP  ", "ZOMBIE ", "BLOCK  ", "FORKED", 0}; 

int kps()
{
   int i,j; 
   char *p, *q, buf[16];
   buf[15] = 0;
   printf("============================================\n");
   printf("  name         status      pid       ppid  \n");
   printf("--------------------------------------------\n");

   for (i=0; i<NPROC; i++){
     if (proc[i].status == FREE)
       continue;
       strcpy(buf,"               ");
       p = proc[i].res->name;
       j = 0;
       while (*p){
             buf[j] = *p; j++; p++;
       }      
       if (i==0)
	 prints("init           ");
       else
         prints(buf);
       prints(" ");
       
       if (proc[i].status != FREE){
           if (running==&proc[i])
              prints("running");
           else
              prints(hh[proc[i].status]);
           prints("     ");
           printi(proc[i].pid);  prints("        ");
           printi(proc[i].ppid);
       }
       else{
              prints("FREE");
       }
       prints("\n\r");
   }
   printf("---------------------------------------------\n");
   printf("running = proc %d = %s\n", running->pid,running->res->name);
   return 0;
}

int chname(int y)
{
  char buf[32];
  char *cp = buf;
  int count = 0; 
  char *b = (char *)y;

  printf("running=%d b=%x esp=%x\n", 
          running->pid, b, getesp());

  while (count < 32){
     *cp = get_ubyte(b);
     putc(*cp);

     if (*cp == 0) break;
     cp++; b++; count++;
  }
  buf[31] = 0;

  printf("changing name of proc %d to %s\n", running->pid, buf);
  strcpy(running->res->name, buf); 
  printf("done\n");
}

int chuid(int uid, int gid)
{
  running->res->uid = uid;
  running->res->gid = gid;
  return 0;
}

int kfixtty(char *y)
{
  char *p; char c;
  p = running->res->tty;

  while(c = get_ubyte(y)){
    *p = c;
    p++; y++;
  }
  *p = 0;
}

int kgettty(char *y)
{
  char *p;

  p = running->res->tty;
  while(*p){
    put_ubyte(*p, y);
    p++; y++;
  }
  put_ubyte(0, y);
}

int getphypage(int *y, int *z)
{
  int i;
  u32 x = (u32)y;
  x += 0x80000000;
  y = (int *)x;
  for (i=0; i<256; i++)
    *z++ = *y++;
  return i;
}

/*********************************************************************
                    syscall routing table
*********************************************************************/

extern int 
getpid(), getppid(), getpri(), ksetpri(), getuid(), kchuid(), kswitch(),
fork(), kexec(), kwait(), vfork(),  kthread(), kmutex_creat(), kmutex_lock(), 
kmutex_unlock(), kmutex_destroy(), kmkdir(), krmdir(), kcreat(), klink(), 
kunlink(), ksymlink(), kreadlink(), kchdir(), kgetcwd(), kstat(), kfstat(), 
kopen(), kclose(), klseek(), kread(), kwrite(), kpipe(), kchmod(), kchown(), 
ktouch(), kfixtty(), kgettty(), kdup(), kdup2(), kps(), kmount(), kumount(), 
kcdSector(), do_cmd(), kkill(), ksignal(), kpause(), kitimer(), ksend(), 
krecv(), ktjoin(), ktexit(), khits(), kcolor(), ksync(), khits(), kexit(),
kgetPaddress(), thinit(), sbrk(), page_out(), ptable();

extern int nocall();
  //fork,     kexec,     kwait,     kgetPaddress,  kthread, 
int (*f[ ])() = {
  getpid,   getppid,   getpri,    ksetpri,  getuid, 
  kchuid,   kswitch,   nocall,    nocall,   kexit,
  fork,     kexec,     kwait,     vfork,    kthread, 
  kmutex_creat, kmutex_lock, kmutex_unlock, kmutex_destroy, nocall,
  kmkdir,   krmdir,    kcreat,    klink,    kunlink, 
  ksymlink, kreadlink, kchdir,    kgetcwd,  kstat, 
  kfstat,   kopen,     kclose,    klseek,   kread, 
  kwrite,   kpipe,     kchmod,    kchown,   ktouch,
  kfixtty,  kgettty,   kdup,      kdup2,    kps, 
  kmount,   kumount,   kcdSector, do_cmd,   nocall, 
  kkill,    ksignal,   kpause,    kitimer,  ksend, 
  krecv,    ktjoin,    ktexit,    khits,    kcolor,   
  ksync,    kps,       thinit,    sbrk,     page_out,
  getphypage,ptable,   kgetPaddress
}; 


int prtable()
{
  u32 *up;
  int i;
  up = (u32 *)0x93000;
  for (i=0; i<8; i++){
    printf("%x ", *up);
    up++;
  }

  printf("\n---------------\n");
  up = (u32 *)0x94000;
  printf("contents at 0x94000\n");
  for (i=0; i<1024; i++){
    printf("%x ", *up);
    up++;
    if ((i%64)==0) kgetc();
  }
  kgetc();
  printf("\n---------------\n");
}

int kcinth(u32 gs, u32 fs, u32 es, u32 ds, u32 di, u32 si, u32 bp, u32 dx, 
u32 cx, u32 bx, volatile u32 ax, u32 upc, u32 ucs, u32 uflag, u32 usp, u32 uss )
{
  int x,y,z,w,ww;
  int i, r;
  u32 *addr;
  u32 *pgtable; int pgentry, frame, pa, oy;
 
  if (running->res->signal)
     kpsig();
  unlock();
  
  addr = (u32 *)usp;

  x = *(addr+1); y=*(addr+2); z=*(addr+3); w=*(addr+4); ww=*(addr+5);
 
  if (x > 67){ // number of syscalls
    printf("invlaid syscall no=%d\n", x);
    return -1;
  }

  r = (*f[x])(y,z,w,ww);     // call the syscall function

  if (running->res->signal)  // check and handle signal
      kpsig();
  ax = r;                    // return value to AX register 
}
