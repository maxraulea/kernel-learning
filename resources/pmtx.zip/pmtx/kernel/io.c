/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/***********************************************************************
                      io.c file of MTX
***********************************************************************/
#include "../include.h"

char *ctable = "0123456789ABCDEF";

void align(), printi(), prints();


char getc()
{
  return kgetc();
}

void gets(char *s)
{   char c; int len=0; 
    while ( (c=getc()) != '\n' && len < 64){
           *s++ = c; len++;
           putc(c); 
    }
    prints("\n\r");
    *s = 0;
}

void kgets(char *s)
{   char c; int len=0; 
    while ( (c=getc()) != '\n' && len < 64){
           *s++ = c; len++;
           putc(c); 
    }
    prints("\n\r");
    *s = 0;
}

void align(u32 x)
{
  int count;
  count = 10;
  if (x==0) 
     count = 9;
  while (x){
    count--;
    x = (u32)(x/10);
  }

  while(count){
    putc(' ');
    count--;
  }
}

void rpi(int x)
{
   char c;
   if (x==0) return;
   c = ctable[x%10];
   rpi((int)x/10);
   putc(c);
}
  
void printi(int x)
{
    if (x==0){
       prints("0 ");
       return;
    }
    if (x < 0){
       putc('-');
       x = -x;
    }
    rpi((int)x);
    putc(' ');
}

void rpu(u32 x)
{
   char c;
   if (x==0) return;
   c = ctable[x%10];
   rpi((u32)x/10);
   putc(c);
}

void printu(u32 x)
{
    if (x==0){
       prints("0 ");
       return;
    }
    rpu((u32)x);
    putc(' ');
}

void rpx(u32 x)
{
   char c;
   if (x==0) return;
   c = ctable[x%16];
   rpx((u32)x/16);
   putc(c);
}

void printx(u32 x)
{  
  prints("0x");
   if (x==0){
      prints("0 ");
      return;
   }
   rpx((u32)x);
  putc(' ');
}

void prints(char *s)
{
   while (*s){
      putc(*s);
      s++;
   }
}

int printc(char c)
{
  putc(c);
  if (c=='\n')
     putc('\r');
}


int printk(char *fmt,...)
{
  char *cp;
  int  *ip;
 
  cp = (char *)fmt;
  ip = (int *)&fmt + 1;

  while (*cp){
    if (*cp != '%'){
      printc(*cp);
      cp++;
      continue;
    }
    cp++;
    switch(*cp){
      case 'd' : printi(*ip); break;
      case 'u' : printu(*ip); break;
      case 'x' : printx(*ip); break;
      case 's' : prints((char *)*ip); break;
      case 'c' : printc((char )*ip);   break;
    }
    cp++; ip++;
  }
  return 1;
}

char get_ubyte(char *b)
{
  return *b;
}

int put_ubyte(char b, char *addr)
{
   *addr = b;
}

char *get_ustring(char *string, char *b)
{
  char *cp = string;
  while ((*cp = get_ubyte(b)) != 0){
         cp++; b++;
  }
  *cp = 0;
  return string; 
}
   
